import React, { useState, useEffect } from 'react';

const MortgageCalculator: React.FC = () => {
  const [price, setPrice] = useState(800000);
  const [downPaymentAmount, setDownPaymentAmount] = useState(160000);
  const [downPaymentPercent, setDownPaymentPercent] = useState(20);
  const [rate, setRate] = useState(5.5);
  const [amortization, setAmortization] = useState(25);
  const [paymentFrequency, setPaymentFrequency] = useState('Monthly');
  const [location, setLocation] = useState<'Ontario' | 'Toronto'>('Toronto');
  const [isFirstTimeBuyer, setIsFirstTimeBuyer] = useState(true);

  // Results
  const [cmhcInsurance, setCmhcInsurance] = useState(0);
  const [landTransferTax, setLandTransferTax] = useState(0);
  const [totalMortgage, setTotalMortgage] = useState(0);
  const [payment, setPayment] = useState(0);

  // Handlers for Down Payment sync
  const handleDownPaymentAmountChange = (val: number) => {
    setDownPaymentAmount(val);
    setDownPaymentPercent(parseFloat(((val / price) * 100).toFixed(2)));
  };

  const handleDownPaymentPercentChange = (val: number) => {
    setDownPaymentPercent(val);
    setDownPaymentAmount(Math.round((val / 100) * price));
  };

  // Logic
  useEffect(() => {
    // 1. Calculate CMHC Insurance
    // Rules: <20% down requires insurance.
    // 5-9.99% down: 4.0% premium
    // 10-14.99% down: 3.10% premium
    // 15-19.99% down: 2.80% premium
    // Note: Standard rules simplified for this tool.
    
    let insurancePremium = 0;
    const mortgageAmount = price - downPaymentAmount;
    
    if (price < 1000000 && downPaymentPercent < 20) {
      if (downPaymentPercent >= 5 && downPaymentPercent < 10) {
        insurancePremium = mortgageAmount * 0.04;
      } else if (downPaymentPercent >= 10 && downPaymentPercent < 15) {
        insurancePremium = mortgageAmount * 0.031;
      } else if (downPaymentPercent >= 15 && downPaymentPercent < 20) {
        insurancePremium = mortgageAmount * 0.028;
      }
    }
    setCmhcInsurance(insurancePremium);

    // 2. Total Mortgage
    const total = mortgageAmount + insurancePremium;
    setTotalMortgage(total);

    // 3. Payment Calculation
    const annualRate = rate / 100;
    let paymentsPerYear = 12;
    if (paymentFrequency === 'Bi-Weekly') paymentsPerYear = 26;
    if (paymentFrequency === 'Accelerated Bi-Weekly') paymentsPerYear = 26;
    if (paymentFrequency === 'Weekly') paymentsPerYear = 52;

    const periodicRate = annualRate / paymentsPerYear; // Simplified compounding for estimate
    const numberOfPayments = amortization * paymentsPerYear;

    let pmt = 0;
    if (periodicRate === 0) {
      pmt = total / numberOfPayments;
    } else {
      pmt = (total * periodicRate * Math.pow(1 + periodicRate, numberOfPayments)) / (Math.pow(1 + periodicRate, numberOfPayments) - 1);
    }
    
    // Adjust for accelerated (simplified logic: take monthly / 2)
    if (paymentFrequency === 'Accelerated Bi-Weekly') {
      // Standard monthly / 2
      const monthlyRate = annualRate / 12;
      const monthlyPmt = (total * monthlyRate * Math.pow(1 + monthlyRate, amortization * 12)) / (Math.pow(1 + monthlyRate, amortization * 12) - 1);
      pmt = monthlyPmt / 2;
    }

    setPayment(pmt);

    // 4. Land Transfer Tax
    // Ontario Brackets
    // 0 - 55k: 0.5%
    // 55k - 250k: 1.0%
    // 250k - 400k: 1.5%
    // 400k - 2m: 2.0%
    // > 2m: 2.5%
    
    const calculateTax = (val: number) => {
      let tax = 0;
      if (val > 2000000) {
        tax += (val - 2000000) * 0.025;
        val = 2000000;
      }
      if (val > 400000) {
        tax += (val - 400000) * 0.02;
        val = 400000;
      }
      if (val > 250000) {
        tax += (val - 250000) * 0.015;
        val = 250000;
      }
      if (val > 55000) {
        tax += (val - 55000) * 0.01;
        val = 55000;
      }
      if (val > 0) {
        tax += val * 0.005;
      }
      return tax;
    };

    let ontarioTax = calculateTax(price);
    let torontoTax = 0;

    if (location === 'Toronto') {
      torontoTax = calculateTax(price); // Toronto LTT structure mirrors Ontario closely for this tool
    }

    // Rebates
    if (isFirstTimeBuyer) {
      ontarioTax = Math.max(0, ontarioTax - 4000);
      if (location === 'Toronto') {
        torontoTax = Math.max(0, torontoTax - 4475);
      }
    }

    setLandTransferTax(ontarioTax + torontoTax);

  }, [price, downPaymentAmount, downPaymentPercent, rate, amortization, paymentFrequency, location, isFirstTimeBuyer]);

  return (
    <div className="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-gray-100">
      <h3 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
        Mortgage Calculator
      </h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* INPUTS */}
        <div className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Asking Price ($)</label>
            <input 
              type="number" 
              value={price} 
              onChange={(e) => {
                const newPrice = Number(e.target.value);
                setPrice(newPrice);
                // Keep downpayment percent constant when price changes
                setDownPaymentAmount(Math.round((downPaymentPercent / 100) * newPrice));
              }}
              className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Down Payment ($)</label>
              <input 
                type="number" 
                value={downPaymentAmount}
                onChange={(e) => handleDownPaymentAmountChange(Number(e.target.value))}
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Percentage (%)</label>
              <input 
                type="number" 
                value={downPaymentPercent}
                onChange={(e) => handleDownPaymentPercentChange(Number(e.target.value))}
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mortgage Rate (%)</label>
              <input 
                type="number" 
                step="0.01"
                value={rate}
                onChange={(e) => setRate(Number(e.target.value))}
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Amortization (Years)</label>
              <select 
                value={amortization}
                onChange={(e) => setAmortization(Number(e.target.value))}
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none bg-white"
              >
                {[15, 20, 25, 30].map(y => <option key={y} value={y}>{y} Years</option>)}
              </select>
            </div>
          </div>

          <div>
             <label className="block text-sm font-medium text-gray-700 mb-1">Payment Frequency</label>
             <select 
                value={paymentFrequency}
                onChange={(e) => setPaymentFrequency(e.target.value)}
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none bg-white"
              >
                <option value="Monthly">Monthly</option>
                <option value="Bi-Weekly">Bi-Weekly</option>
                <option value="Accelerated Bi-Weekly">Accelerated Bi-Weekly</option>
                <option value="Weekly">Weekly</option>
              </select>
          </div>

          <div className="pt-4 border-t border-gray-100">
             <h4 className="font-bold text-sm mb-3 text-gray-900">Land Transfer Tax Settings</h4>
             <div className="flex flex-wrap gap-4 mb-3">
               <label className="flex items-center gap-2 cursor-pointer">
                 <input 
                   type="radio" 
                   checked={location === 'Toronto'} 
                   onChange={() => setLocation('Toronto')}
                   className="text-black focus:ring-black"
                 />
                 <span className="text-sm">Toronto</span>
               </label>
               <label className="flex items-center gap-2 cursor-pointer">
                 <input 
                   type="radio" 
                   checked={location === 'Ontario'} 
                   onChange={() => setLocation('Ontario')}
                   className="text-black focus:ring-black"
                 />
                 <span className="text-sm">Ontario (Outside Toronto)</span>
               </label>
             </div>
             <label className="flex items-center gap-2 cursor-pointer">
                <input 
                   type="checkbox" 
                   checked={isFirstTimeBuyer} 
                   onChange={(e) => setIsFirstTimeBuyer(e.target.checked)}
                   className="rounded text-black focus:ring-black"
                />
                <span className="text-sm">First-Time Home Buyer (Rebate Applied)</span>
             </label>
          </div>
        </div>

        {/* RESULTS */}
        <div className="bg-gray-50 rounded-xl p-6 flex flex-col h-full justify-between">
           <div className="text-center mb-8">
             <p className="text-gray-500 font-medium mb-1">{paymentFrequency} Payment</p>
             <div className="text-4xl md:text-5xl font-extrabold text-black mb-2">
               ${payment.toLocaleString(undefined, { maximumFractionDigits: 2 })}
             </div>
           </div>

           <div className="space-y-4 text-sm text-gray-700">
             <div className="flex justify-between border-b border-gray-200 pb-2">
               <span>Mortgage Principal</span>
               <span className="font-semibold">${(price - downPaymentAmount).toLocaleString()}</span>
             </div>
             <div className="flex justify-between border-b border-gray-200 pb-2">
               <span>CMHC Insurance</span>
               <span className="font-semibold text-red-600">+${cmhcInsurance.toLocaleString()}</span>
             </div>
             <div className="flex justify-between font-bold text-black text-base pb-4">
               <span>Total Mortgage</span>
               <span>${totalMortgage.toLocaleString()}</span>
             </div>

             <div className="pt-4">
               <p className="font-bold text-gray-900 mb-2">Required Upfront Cash</p>
               <div className="flex justify-between py-1">
                 <span>Down Payment</span>
                 <span>${downPaymentAmount.toLocaleString()}</span>
               </div>
               <div className="flex justify-between py-1">
                 <span>Land Transfer Tax</span>
                 <span>${landTransferTax.toLocaleString()}</span>
               </div>
               <div className="flex justify-between border-t border-gray-300 pt-2 font-bold mt-2">
                 <span>Total Cash Needed</span>
                 <span>${(downPaymentAmount + landTransferTax).toLocaleString()}</span>
               </div>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default MortgageCalculator;