import React, { useState } from 'react';

interface LeadFormProps {
  type?: 'General' | 'Mortgage' | 'Realtor' | 'Legal' | 'Contractor' | 'Pre-Con';
  title?: string;
  subtitle?: string;
}

const LeadForm: React.FC<LeadFormProps> = ({ 
  type = 'General', 
  title = 'How Can We Help You Today?', 
  subtitle = 'One form. One team. Complete solution.' 
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    serviceNeeded: type === 'General' ? 'Mortgage' : type,
    postalCode: '',
    message: '',
    consent: false
  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.consent) {
      setError('You must check the consent box to proceed.');
      return;
    }
    setError('');
    
    // Redirect logic for Mortgage
    if (formData.serviceNeeded === 'Mortgage') {
      window.open('https://gopineapple.ca/muditchhura/preapproval', '_blank');
      setSubmitted(true);
      return;
    }

    // Simulate API call for other services
    setTimeout(() => {
      setSubmitted(true);
      console.log('Lead Captured:', { ...formData });
    }, 800);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const value = e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value;
    setFormData({ ...formData, [e.target.name]: value });
  };

  if (submitted) {
    return (
      <div className="bg-black text-white p-16 rounded-3xl text-center shadow-2xl border border-white/10">
        <h3 className="text-4xl font-black mb-4 uppercase tracking-tighter">Request Received</h3>
        <p className="text-gray-400 text-lg mb-8">
          {formData.serviceNeeded === 'Mortgage' 
            ? "We've redirected you to the pre-approval portal. Our team will follow up shortly."
            : "Your request has been routed to our expert network. You will hear from us within 24 hours."}
        </p>
        <button 
          onClick={() => setSubmitted(false)} 
          className="text-white font-black uppercase text-xs tracking-widest hover:underline"
        >
          Submit Another Request
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white p-8 md:p-12 rounded-3xl shadow-2xl border border-gray-100">
      <h3 className="text-3xl font-black text-black mb-2 uppercase tracking-tight">{title}</h3>
      <p className="text-gray-500 mb-10 text-sm font-medium">{subtitle}</p>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">I Need Help With</label>
          <select
            name="serviceNeeded"
            className="w-full px-5 py-4 bg-gray-50 border-none rounded-xl font-bold text-black focus:ring-2 focus:ring-black transition outline-none appearance-none"
            value={formData.serviceNeeded}
            onChange={handleChange}
          >
            <option value="Mortgage">I need a Mortgage (Pre-Approval)</option>
            <option value="Realtor">I need a Realtor (Buy/Sell)</option>
            <option value="Legal">I need a Real Estate Lawyer</option>
            <option value="Contractor">I need a Contractor (Renovation)</option>
            <option value="Pre-Con">I want Platinum Pre-Construction Access</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Full Name</label>
            <input
              type="text"
              name="name"
              required
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-xl font-bold text-black focus:ring-2 focus:ring-black outline-none"
              placeholder="John Doe"
              value={formData.name}
              onChange={handleChange}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">City / Postal Code</label>
            <input
              type="text"
              name="postalCode"
              required
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-xl font-bold text-black focus:ring-2 focus:ring-black outline-none"
              placeholder="e.g. M5V 1J2"
              value={formData.postalCode}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Email Address</label>
            <input
              type="email"
              name="email"
              required
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-xl font-bold text-black focus:ring-2 focus:ring-black outline-none"
              placeholder="name@example.com"
              value={formData.email}
              onChange={handleChange}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Phone Number</label>
            <input
              type="tel"
              name="phone"
              required
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-xl font-bold text-black focus:ring-2 focus:ring-black outline-none"
              placeholder="(416) 000-0000"
              value={formData.phone}
              onChange={handleChange}
            />
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Briefly Describe Your Needs</label>
          <textarea
            name="message"
            rows={4}
            className="w-full px-5 py-4 bg-gray-50 border-none rounded-xl font-bold text-black focus:ring-2 focus:ring-black outline-none"
            placeholder="e.g. I'm looking to buy my first home in Vaughan..."
            value={formData.message}
            onChange={handleChange}
          ></textarea>
        </div>

        {/* Legal Consent - Unchecked by Default */}
        <div className="flex items-start gap-4 py-4 border-y border-gray-100">
          <input 
            type="checkbox" 
            name="consent"
            id="consent"
            checked={formData.consent}
            onChange={handleChange}
            className="mt-1 w-5 h-5 text-black border-gray-300 rounded-lg focus:ring-black"
          />
          <label htmlFor="consent" className="text-[10px] text-gray-500 font-bold uppercase tracking-wider leading-relaxed cursor-pointer select-none">
            I consent to be contacted by Mudit Chhura and the IndiBrick partner network regarding my inquiry. I understand I can opt-out at any time.
          </label>
        </div>

        {error && <p className="text-red-600 text-[10px] font-black uppercase tracking-widest text-center">{error}</p>}

        <button
          type="submit"
          className="w-full bg-black text-white font-black uppercase text-sm tracking-[0.2em] py-5 rounded-2xl hover:bg-gray-800 transition shadow-xl"
        >
          {formData.serviceNeeded === 'Mortgage' ? "Start Pre-Approval Now" : "Request Specialist Match"}
        </button>

        <p className="text-[9px] text-gray-400 text-center uppercase font-bold tracking-widest px-8">
          By submitting, you agree to our privacy policy. Your data is protected and will only be shared with the specific partner required for your service.
        </p>
      </form>
    </div>
  );
};

export default LeadForm;