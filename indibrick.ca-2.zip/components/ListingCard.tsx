import React from 'react';
import { Property } from '../types';
import { Bed, Bath, MapPin, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ListingCardProps {
  property: Property;
}

const ListingCard: React.FC<ListingCardProps> = ({ property }) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-200 flex flex-col h-full group">
      <div className="relative overflow-hidden h-48 bg-gray-200">
        <img 
          src={property.imageUrl} 
          alt={property.title} 
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500 grayscale group-hover:grayscale-0"
        />
        <div className="absolute top-3 left-3 flex gap-2">
           <span className={`px-3 py-1 text-xs font-bold rounded-full uppercase tracking-wider border border-white/20 shadow-sm ${
             property.purpose === 'Rent' ? 'bg-black text-white' : 
             property.purpose === 'Pre-Construction' ? 'bg-white text-black' : 
             'bg-gray-800 text-white'
           }`}>
             {property.purpose}
           </span>
           {property.isFeatured && (
             <span className="bg-white text-black px-3 py-1 text-xs font-bold rounded-full uppercase tracking-wider shadow-sm">
               Featured
             </span>
           )}
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
           <p className="text-white font-bold text-xl">${property.price.toLocaleString()}</p>
        </div>
      </div>
      
      <div className="p-5 flex-grow flex flex-col">
        <h3 className="text-lg font-bold text-gray-900 mb-1 group-hover:text-black transition-colors line-clamp-1">{property.title}</h3>
        <div className="flex items-center text-gray-500 text-sm mb-4">
          <MapPin size={14} className="mr-1" />
          <span className="truncate">{property.address}, {property.city}</span>
        </div>
        
        <div className="flex items-center gap-4 mb-5 pb-5 border-b border-gray-100">
          <div className="flex items-center text-sm text-gray-600">
            <Bed size={16} className="mr-1.5 text-black" />
            <span className="font-semibold mr-1">{property.bedrooms}</span> Bed
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <Bath size={16} className="mr-1.5 text-black" />
            <span className="font-semibold mr-1">{property.bathrooms}</span> Bath
          </div>
           <div className="flex items-center text-sm text-gray-600">
            <span className="px-2 py-0.5 bg-gray-100 rounded text-xs border border-gray-200">{property.type}</span>
          </div>
        </div>
        
        <div className="mt-auto">
          <Link 
            to={`/listings`} 
            className="w-full flex items-center justify-center gap-2 bg-gray-50 text-gray-800 font-semibold py-2.5 rounded-lg hover:bg-black hover:text-white transition-colors border border-gray-200 hover:border-black"
          >
            View Details <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ListingCard;