import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Mail, MapPin, Phone, ShieldCheck, Globe } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-white pt-32 pb-16">
      <div className="container mx-auto px-6">
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-20 mb-32">
          
          <div className="space-y-10">
            <div>
               <div className="flex items-center gap-3 mb-6">
                <svg viewBox="0 0 100 100" className="w-12 h-12 text-white" fill="currentColor"><rect x="10" y="5" width="80" height="18" rx="2" /><rect x="10" y="28" width="38" height="18" rx="2" /><rect x="52" y="28" width="38" height="18" rx="2" /><rect x="10" y="51" width="80" height="18" rx="2" /><rect x="10" y="74" width="38" height="18" rx="2" /><rect x="52" y="74" width="38" height="18" rx="2" /></svg>
                <div className="flex flex-col">
                  <span className="text-3xl font-black tracking-tighter text-white uppercase leading-none">INDIBRICK</span>
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500">The Ecosystem</span>
                </div>
              </div>
              <p className="text-sm text-gray-500 font-medium leading-relaxed max-w-xs">
                Ontario's premier mortgage-led real estate hub. Connecting you to verified professionals for every structural phase of home ownership.
              </p>
            </div>
            
            <div className="flex gap-6 opacity-40 hover:opacity-100 transition-opacity">
              <a href="#"><Facebook size={20} /></a>
              <a href="#"><Instagram size={20} /></a>
              <a href="#"><Linkedin size={20} /></a>
            </div>
          </div>

          <div>
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-12 text-gray-500">The Command</h3>
            <ul className="space-y-5 text-xs font-black uppercase tracking-widest">
              <li><Link to="/services" className="text-white hover:text-gray-400 transition">Mortgage Strategy</Link></li>
              <li><Link to="/listings" className="text-white hover:text-gray-400 transition">Partner Properties</Link></li>
              <li><Link to="/pre-construction" className="text-white hover:text-gray-400 transition">Pre-Construction</Link></li>
              <li><Link to="/renovation-financing" className="text-white hover:text-gray-400 transition">Reno Financing</Link></li>
              <li><Link to="/careers" className="text-white hover:text-gray-400 transition">Join the Team</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-12 text-gray-500">Insights</h3>
            <ul className="space-y-5 text-xs font-black uppercase tracking-widest">
              <li><Link to="/learn" className="text-white hover:text-gray-400 transition">Knowledge Hub</Link></li>
              <li><Link to="/tools" className="text-white hover:text-gray-400 transition">Calculators</Link></li>
              <li><Link to="/admin" className="text-white hover:text-gray-400 transition">Partner Portal</Link></li>
              <li><Link to="/privacy-policy" className="text-white hover:text-gray-400 transition">Legal & Privacy</Link></li>
            </ul>
          </div>

          <div className="space-y-12">
            <div>
               <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-gray-500">Official Identity</h3>
               <div className="space-y-2">
                 <p className="font-black text-xl text-white">Mudit Chhura</p>
                 <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest">Mortgage Agent Level 1</p>
                 <p className="text-[10px] text-gray-500 font-bold">FSRA Agent License #: M25003057</p>
                 <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest pt-4">Brokerage: Pineapple</p>
                 <p className="text-[10px] text-gray-500 font-bold">FSRA Brokerage License #: 12830</p>
               </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-white/10">
               <li className="flex items-start gap-4 text-gray-400 text-xs">
                 <MapPin className="text-white shrink-0" size={16} />
                 <span>60 Pippin Rd Unit 34, Vaughan, ON</span>
               </li>
               <li className="flex items-center gap-4 text-gray-400 text-xs">
                 <Phone className="text-white shrink-0" size={16} />
                 <span className="font-black text-white">(437) 241-6392</span>
               </li>
               <li className="flex items-center gap-4 text-gray-400 text-xs">
                 <Mail className="text-white shrink-0" size={16} />
                 <span>muditchhura@gopineapple.com</span>
               </li>
            </div>
          </div>
        </div>

        {/* NEW: SEO CITY ECOSYSTEM SECTION */}
        <div className="border-t border-white/10 pt-16 mb-20">
           <div className="flex items-center gap-3 mb-10">
              <Globe size={18} className="text-white/30" />
              <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500">Local Service Ecosystem</h3>
           </div>
           <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-y-10 gap-x-6">
              {[
                { name: 'Toronto', slug: 'toronto' },
                { name: 'Brampton', slug: 'brampton' },
                { name: 'Mississauga', slug: 'mississauga' },
                { name: 'Vaughan', slug: 'vaughan' },
                { name: 'Scarborough', slug: 'scarborough' },
                { name: 'Oakville', slug: 'oakville' },
                { name: 'Milton', slug: 'milton' },
                { name: 'Markham', slug: 'markham' },
                { name: 'Richmond Hill', slug: 'richmond-hill' },
                { name: 'Etobicoke', slug: 'etobicoke' }
              ].map(city => (
                <div key={city.slug} className="space-y-3">
                   <p className="text-xs font-black text-white uppercase tracking-tighter">{city.name}</p>
                   <ul className="space-y-2">
                      <li><Link to={`/mortgage-real-estate-${city.slug}`} className="text-[10px] text-gray-500 hover:text-white transition font-bold uppercase tracking-widest">Mortgage Hub</Link></li>
                      <li><Link to={`/pre-construction-condos-${city.slug}`} className="text-[10px] text-gray-500 hover:text-white transition font-bold uppercase tracking-widest">Pre-Con Projects</Link></li>
                   </ul>
                </div>
              ))}
           </div>
        </div>

        {/* Legal Disclaimers & Copyright */}
        <div className="border-t border-white/10 pt-16 space-y-10">
          <div className="bg-white/5 p-8 rounded-2xl">
             <div className="flex items-start gap-4">
                <ShieldCheck size={24} className="text-white/50 shrink-0" />
                <p className="text-[9px] text-gray-500 uppercase font-black tracking-widest leading-relaxed">
                  Partner Disclaimer: Real estate, legal, renovation, and property management services are provided by independent third-party professionals. 
                  IndiBrick.ca and Mudit Chhura act solely as a licensed mortgage agent and connect clients to these professionals as a value-added service. 
                  Users are encouraged to conduct their own due diligence before signing contracts with any third-party partner. 
                  All mortgage transactions are conducted through Pineapple (License # 12830).
                </p>
             </div>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 text-[10px] font-black uppercase tracking-[0.4em] text-gray-500">
            <p>© {new Date().getFullYear()} INDIBRICK.CA • OPERATED BY PINEAPPLE</p>
            <div className="flex gap-10">
              <Link to="/privacy-policy" className="hover:text-white transition">Privacy</Link>
              <Link to="#" className="hover:text-white transition">CASL</Link>
              <Link to="#" className="hover:text-white transition">Terms</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
