import React, { useState } from 'react';

const TriggerRateCalculator: React.FC = () => {
  const [balance, setBalance] = useState(500000);
  const [payment, setPayment] = useState(2500);
  const [frequency, setFrequency] = useState('Monthly');
  
  const calculateTriggerRate = () => {
    let paymentsPerYear = 12;
    if (frequency === 'Bi-Weekly') paymentsPerYear = 26;
    if (frequency === 'Weekly') paymentsPerYear = 52;
    if (frequency === 'Semi-Monthly') paymentsPerYear = 24;

    // Formula: ((Payment Amount * Payments Per Year) / Mortgage Balance) * 100
    const triggerRate = ((payment * paymentsPerYear) / balance) * 100;
    return triggerRate.toFixed(2);
  };

  return (
    <div className="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-gray-100">
      <h3 className="text-2xl font-bold text-slate-900 mb-2">Trigger Rate Calculator</h3>
      <p className="text-gray-500 mb-6 text-sm">
        Find out at what interest rate your payments will only cover interest (and no principal).
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Current Mortgage Balance ($)</label>
            <input 
              type="number"
              value={balance}
              onChange={(e) => setBalance(Number(e.target.value))}
              className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Current Payment Amount ($)</label>
            <input 
              type="number"
              value={payment}
              onChange={(e) => setPayment(Number(e.target.value))}
              className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Payment Frequency</label>
            <select
              value={frequency}
              onChange={(e) => setFrequency(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none bg-white"
            >
              <option value="Monthly">Monthly</option>
              <option value="Semi-Monthly">Semi-Monthly</option>
              <option value="Bi-Weekly">Bi-Weekly</option>
              <option value="Weekly">Weekly</option>
            </select>
          </div>
        </div>

        <div className="bg-gray-900 rounded-xl p-8 text-center text-white flex flex-col items-center justify-center h-full">
           <span className="text-gray-400 font-medium mb-2 uppercase tracking-widest text-xs">Your Trigger Rate</span>
           <span className="text-5xl font-bold text-white mb-2">{calculateTriggerRate()}%</span>
           <p className="text-gray-400 text-xs mt-2 max-w-xs">
             If your variable rate exceeds this number, your payment may not cover the interest due, potentially increasing your balance.
           </p>
        </div>
      </div>
    </div>
  );
};

export default TriggerRateCalculator;