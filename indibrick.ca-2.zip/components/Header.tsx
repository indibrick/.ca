import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Building, Home, Hammer, Calculator, BookOpen, UserPlus, Zap, ChevronDown, MapPin } from 'lucide-react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isCityOpen, setIsCityOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'Listings', path: '/listings', icon: Building },
    { name: 'Services', path: '/services', icon: Hammer },
    { name: 'Learn', path: '/learn', icon: BookOpen },
    { name: 'Careers', path: '/careers', icon: UserPlus },
    { name: 'Tools', path: '/tools', icon: Calculator },
  ];

  const cities = [
    { name: 'Toronto', path: '/mortgage-real-estate-toronto' },
    { name: 'Brampton', path: '/mortgage-real-estate-brampton' },
    { name: 'Mississauga', path: '/mortgage-real-estate-mississauga' },
    { name: 'Vaughan', path: '/mortgage-real-estate-vaughan' },
  ];

  const isActive = (path: string) => location.pathname === path || (path !== '/' && location.pathname.startsWith(path));

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-24">
          <Link to="/" className="flex items-center gap-4 group">
            <div className="flex items-center gap-3">
              <svg viewBox="0 0 100 100" className="w-12 h-12 text-black group-hover:opacity-80 transition" fill="currentColor"><rect x="10" y="5" width="80" height="18" rx="2" /><rect x="10" y="28" width="38" height="18" rx="2" /><rect x="52" y="28" width="38" height="18" rx="2" /><rect x="10" y="51" width="80" height="18" rx="2" /><rect x="10" y="74" width="38" height="18" rx="2" /><rect x="52" y="74" width="38" height="18" rx="2" /></svg>
              <div className="flex flex-col">
                <span className="text-2xl font-black tracking-tighter text-black uppercase leading-none">INDIBRICK</span>
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400">The Ecosystem</span>
              </div>
            </div>
            
            <div className="h-10 w-px bg-gray-200 mx-2 hidden md:block"></div>
            
            <div className="hidden lg:flex flex-col">
              <span className="text-sm font-black text-black leading-tight">Mudit Chhura</span>
              <span className="text-[10px] text-gray-400 uppercase tracking-widest font-black">Mortgage Agent L1 • # M25003057</span>
            </div>
          </Link>

          <nav className="hidden xl:flex space-x-8 items-center">
            <div 
              className="relative group"
              onMouseEnter={() => setIsCityOpen(true)}
              onMouseLeave={() => setIsCityOpen(false)}
            >
              <button className="text-[10px] font-black uppercase tracking-[0.2em] transition-colors hover:text-black flex items-center gap-1 text-gray-400">
                Local Hubs <ChevronDown size={14} />
              </button>
              {isCityOpen && (
                <div className="absolute top-full -left-4 pt-4 animate-fade-in">
                  <div className="bg-white border border-gray-100 shadow-2xl rounded-2xl w-56 overflow-hidden">
                    {cities.map(c => (
                      <Link 
                        key={c.path} 
                        to={c.path}
                        className="flex items-center gap-3 px-6 py-4 hover:bg-gray-50 text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-black transition"
                      >
                        <MapPin size={12} /> {c.name}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`text-[10px] font-black uppercase tracking-[0.2em] transition-colors hover:text-black ${
                  isActive(link.path) ? 'text-black border-b-2 border-black pb-1' : 'text-gray-400'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <a 
              href="https://gopineapple.ca/muditchhura/preapproval"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-3 bg-black text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-800 transition shadow-xl"
            >
              <Zap size={14} /> Start Pre-Approval
            </a>
            <button onClick={() => setIsOpen(!isOpen)} className="xl:hidden text-black focus:outline-none">
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="xl:hidden bg-white border-t border-gray-100 py-8 px-6 shadow-2xl absolute w-full animate-fade-in max-h-screen overflow-y-auto">
          <nav className="flex flex-col space-y-8">
            <div className="space-y-4">
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-300">City Hubs</p>
              <div className="grid grid-cols-2 gap-4">
                {cities.map(c => (
                   <Link key={c.path} to={c.path} onClick={() => setIsOpen(false)} className="text-sm font-black uppercase tracking-tight text-black flex items-center gap-2">
                     <MapPin size={16} /> {c.name}
                   </Link>
                ))}
              </div>
            </div>
            <div className="h-px bg-gray-100 w-full"></div>
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={`text-xl font-black uppercase tracking-tighter flex items-center gap-4 ${isActive(link.path) ? 'text-black' : 'text-gray-400'}`}
              >
                {link.icon && <link.icon size={24} />} {link.name}
              </Link>
            ))}
            <div className="pt-8 border-t border-gray-100">
               <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Mudit Chhura</p>
               <p className="text-[10px] font-bold text-gray-500 uppercase">Brokerage: Pineapple • # 12830</p>
            </div>
            <a href="https://gopineapple.ca/muditchhura/preapproval" target="_blank" rel="noopener noreferrer" className="bg-black text-white text-center py-5 rounded-2xl font-black uppercase tracking-widest">Apply Now</a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
