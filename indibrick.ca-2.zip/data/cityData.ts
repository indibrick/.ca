import { CityData, PreConCityData } from '../types';

export const CITIES: CityData[] = [
  {
    slug: 'toronto',
    name: 'Toronto',
    description: 'The heart of Canada\'s financial and cultural landscape, Toronto offers diverse real estate opportunities from high-rise luxury condos to historic detached homes.',
    avgHomePrice: '$1,150,000',
    avgRent: '$2,700',
    marketTrend: 'Steady demand in core neighborhoods with increasing interest in renovated "Purchase Plus" opportunities.',
    mortgageInsights: 'Toronto properties often require specialized high-ratio or conventional financing strategies due to higher valuations.',
    realtorInsights: 'Our Toronto partners specialize in both the luxury market and first-time buyer condo segments.',
    legalInsights: 'Toronto legal closings involve specific municipal land transfer tax considerations.',
    renoInsights: 'High demand for basement apartment conversions and legal suite additions in Toronto freehold homes.',
    faqs: [
      { question: 'What is the Toronto Municipal Land Transfer Tax?', answer: 'In Toronto, buyers pay both Provincial and Municipal land transfer tax, effectively doubling the closing cost compared to other Ontario cities.' },
      { question: 'Can I get a 5% down payment in Toronto?', answer: 'For homes under $500,000, 5% is possible. For homes between $500k and $1M, it is 5% on the first $500k and 10% on the remainder. Homes over $1M require 20% down.' }
    ]
  },
  {
    slug: 'brampton',
    name: 'Brampton',
    description: 'One of the fastest-growing cities in Canada, Brampton is a hub for multi-generational families and real estate investors looking for strong rental yields.',
    avgHomePrice: '$1,020,000',
    avgRent: '$2,400',
    marketTrend: 'Strong demand for detached and semi-detached homes with basement rental potential.',
    mortgageInsights: 'Brampton borrowers often benefit from rental-offset programs that count second-unit income toward qualification.',
    realtorInsights: 'Our Brampton team excels at finding homes with legal secondary suite potential.',
    legalInsights: 'Brampton-specific zoning bylaws for legal basement apartments must be verified during legal due diligence.',
    renoInsights: 'Specializing in legal basement finishes and secondary entrance construction to boost home value.',
    faqs: [
      { question: 'Are basement apartments legal in Brampton?', answer: 'Yes, but they must be registered with the City of Brampton and meet fire and building code requirements to be considered legal.' },
      { question: 'How much do I need for a down payment in Brampton?', answer: 'Similar to other Ontario cities, 5% on the first $500k and 10% on the next $499k for owner-occupied homes.' }
    ]
  },
  {
    slug: 'mississauga',
    name: 'Mississauga',
    description: 'Mississauga offers a balanced mix of urban living and suburban comfort, with a thriving pre-construction condo market in Square One.',
    avgHomePrice: '$1,080,000',
    avgRent: '$2,550',
    marketTrend: 'High volume of pre-construction condo sales and resale detached homes in established communities like Lorne Park.',
    mortgageInsights: 'Perfect for first-time buyers utilizing the FHSA and investors utilizing HELOC strategies.',
    realtorInsights: 'Deep connections with builders in the Square One and Port Credit waterfront areas.',
    legalInsights: 'Expert handling of condo status certificate reviews for Mississauga high-rises.',
    renoInsights: 'Focus on condo upgrades and full-home renovations in Mississauga suburban pockets.',
    faqs: [
      { question: 'Is Mississauga better for investment than Toronto?', answer: 'Mississauga offers slightly lower entry prices than Toronto core while maintaining high rental demand and lower municipal taxes.' },
      { question: 'What are the closing costs in Mississauga?', answer: 'The primary cost is Provincial Land Transfer Tax. Unlike Toronto, there is no additional Municipal Land Transfer Tax here.' }
    ]
  }
];

export const PRE_CON_CITIES: PreConCityData[] = [
  {
    slug: 'toronto',
    cityName: 'Toronto',
    projects: [
      {
        name: 'The Core Residences',
        builder: 'Elite Builders Group',
        type: 'Condominium',
        status: 'Platinum Access',
        description: 'Luxury living in the heart of Downtown Toronto with unmatched amenities.',
        highlights: ['Steps from Subway', 'Day 1 Pricing', 'Special Investor Incentives']
      }
    ]
  },
  {
    slug: 'mississauga',
    cityName: 'Mississauga',
    projects: [
      {
        name: 'Square One District',
        builder: 'Urban Vision',
        type: 'Mixed Use / Condo',
        status: 'Selling Now',
        description: 'The future of Mississauga\'s urban core. A master-planned community.',
        highlights: ['Waterfront views', 'LRT Access', 'Flexible Deposit Structure']
      }
    ]
  }
];
