import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { KNOWLEDGE_BASE } from '../data/knowledgeBase';
import { ArrowLeft, CheckCircle, HelpCircle, Phone } from 'lucide-react';

const ArticlePage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const article = KNOWLEDGE_BASE.find(a => a.slug === slug);

  if (!article) {
    return <Navigate to="/learn" />;
  }

  // Construct JSON-LD Schema for FAQPage
  const schemaData = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": article.faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };

  return (
    <div className="bg-white min-h-screen pb-20">
      {/* Schema Injection */}
      <script type="application/ld+json">
        {JSON.stringify(schemaData)}
      </script>

      {/* Breadcrumb / Header */}
      <div className="bg-gray-50 border-b border-gray-200 py-8">
        <div className="container mx-auto px-4">
          <Link to="/learn" className="inline-flex items-center text-sm text-gray-500 hover:text-black mb-4">
            <ArrowLeft size={16} className="mr-1" /> Back to Knowledge Hub
          </Link>
          <div className="flex items-center gap-2 text-xs font-bold text-black uppercase tracking-wider mb-2">
            <span className="bg-black text-white px-2 py-1 rounded">{article.category}</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold text-black leading-tight max-w-4xl">
            {article.title}
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Featured Snippet (The Answer) */}
            <div className="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-lg mb-8">
              <h3 className="text-green-800 font-bold mb-2 flex items-center gap-2">
                <CheckCircle size={20} /> Quick Answer
              </h3>
              <p className="text-green-900 text-lg leading-relaxed font-medium">
                {article.snippet}
              </p>
            </div>

            {/* Article Body */}
            <div className="prose prose-lg max-w-none text-gray-700 mb-12">
              {article.content}
            </div>

            {/* FAQ Section */}
            <div className="bg-gray-50 rounded-xl p-8 border border-gray-200">
              <h3 className="text-2xl font-bold text-black mb-6 flex items-center gap-2">
                <HelpCircle size={24} /> Frequently Asked Questions
              </h3>
              <div className="space-y-6">
                {article.faqs.map((faq, index) => (
                  <div key={index} className="border-b border-gray-200 pb-4 last:border-0 last:pb-0">
                    <h4 className="font-bold text-black text-lg mb-2">{faq.question}</h4>
                    <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-8">
            {/* Author Box */}
            <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 rounded-full bg-gray-200 overflow-hidden">
                   {/* Placeholder for Mudit's image */}
                   <svg className="w-full h-full text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                     <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                   </svg>
                </div>
                <div>
                  <h3 className="font-bold text-black">Mudit Chhura</h3>
                  <p className="text-xs text-gray-500 uppercase">Mortgage Agent L1</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Specializing in complex income qualification and investment strategies for GTA homeowners.
              </p>
              <a 
                href="https://gopineapple.ca/muditchhura/preapproval" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block w-full text-center bg-black text-white font-bold py-2 rounded hover:bg-gray-800 transition"
              >
                Start Application
              </a>
            </div>

            {/* Sticky CTA */}
            <div className="sticky top-28 bg-blue-50 border border-blue-100 rounded-xl p-6">
              <h3 className="font-bold text-blue-900 text-lg mb-2">Need a custom strategy?</h3>
              <p className="text-blue-800 text-sm mb-4">
                Every financial situation is different. Let's run the numbers for your specific scenario.
              </p>
              <div className="space-y-3">
                 <Link to="/contact" className="flex items-center justify-center gap-2 w-full bg-blue-600 text-white font-bold py-3 rounded hover:bg-blue-700 transition">
                   <Phone size={18} /> Book a Call
                 </Link>
                 <Link to="/tools" className="flex items-center justify-center gap-2 w-full bg-white text-blue-600 border border-blue-200 font-bold py-3 rounded hover:bg-blue-50 transition">
                   Calculators
                 </Link>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default ArticlePage;
