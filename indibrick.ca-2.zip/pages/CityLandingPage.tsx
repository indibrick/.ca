import React, { useEffect } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { CITIES } from '../data/cityData';
import { ArrowRight, BadgeCheck, CheckCircle, TrendingUp, ShieldCheck, MapPin, Zap, Building2, Scale, Hammer } from 'lucide-react';
import LeadForm from '../components/LeadForm';

const CityLandingPage: React.FC = () => {
  const { city } = useParams<{ city: string }>();
  const cityData = CITIES.find(c => c.slug === (city?.replace('mortgage-real-estate-', '') || ''));

  useEffect(() => {
    if (cityData) {
      document.title = `Mortgages, Realtors & Renovation in ${cityData.name} | IndiBrick`;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute('content', `Get pre-approved and buy with confidence in ${cityData.name}. IndiBrick connects you with mortgages, realtors, lawyers & contractors across ${cityData.name}.`);
      }
    }
  }, [cityData]);

  if (!cityData) {
    return <Navigate to="/" />;
  }

  const schemaData = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": cityData.faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };

  return (
    <div className="bg-white">
      <script type="application/ld+json">
        {JSON.stringify(schemaData)}
      </script>

      {/* H1 HERO SECTION */}
      <section className="bg-black text-white py-24 border-b border-white/10">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <div className="flex items-center gap-2 text-gray-400 font-black uppercase text-xs tracking-[0.3em] mb-6">
              <MapPin size={14} /> Ontario Local Hub
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-8 leading-tight tracking-tighter">
              One-Stop Mortgage & Real Estate Solution in {cityData.name}
            </h1>
            <p className="text-xl text-gray-400 mb-10 leading-relaxed max-w-2xl">
              {cityData.description} Build your financing strategy and connect with the best {cityData.name} realtors and legal experts.
            </p>
            <div className="flex flex-col sm:flex-row gap-6">
              <a 
                href="https://gopineapple.ca/muditchhura/preapproval" 
                target="_blank" 
                className="bg-white text-black px-10 py-4 rounded-2xl font-black uppercase text-sm tracking-widest hover:bg-gray-200 transition"
              >
                Start My {cityData.name} Pre-Approval
              </a>
              <Link to="/listings" className="border border-white/30 text-white px-10 py-4 rounded-2xl font-black uppercase text-sm tracking-widest hover:bg-white/10 transition text-center">
                Explore {cityData.name} Homes
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 1 - MORTGAGE (PRIMARY) */}
      <section className="py-24 border-b border-gray-100">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-5xl font-black text-black mb-6 uppercase tracking-tighter">
                Mortgage Strategy for {cityData.name}
              </h2>
              <p className="text-gray-600 text-lg mb-8">
                {cityData.mortgageInsights} We help first-time buyers, investors, and homeowners in {cityData.name} secure the best rates with a custom strategy.
              </p>
              <ul className="space-y-4 mb-10">
                {['First-Time Buyer Programs', 'Rental Property Financing', 'Private Lending for {cityData.name}', 'Refinancing & Equity Takeouts'].map(item => (
                  <li key={item} className="flex items-center gap-3 font-bold text-black uppercase text-xs tracking-widest">
                    <CheckCircle size={18} className="text-black" /> {item.replace('{cityData.name}', cityData.name)}
                  </li>
                ))}
              </ul>
              <a 
                href="https://gopineapple.ca/muditchhura/preapproval" 
                className="inline-flex items-center gap-2 bg-black text-white px-8 py-4 rounded-xl font-black uppercase text-xs tracking-widest hover:bg-gray-800 transition"
              >
                Start Strategy Session <ArrowRight size={16} />
              </a>
            </div>
            <div className="bg-gray-50 p-12 rounded-3xl border border-gray-100 shadow-sm">
               <div className="text-center">
                 <p className="text-gray-400 font-black uppercase text-[10px] tracking-widest mb-2">Market Data</p>
                 <h3 className="text-4xl font-black text-black mb-1">{cityData.avgHomePrice}</h3>
                 <p className="text-gray-500 font-bold mb-8">Avg Home Price in {cityData.name}</p>
                 <div className="h-px bg-gray-200 w-full mb-8"></div>
                 <div className="grid grid-cols-2 gap-8">
                    <div>
                      <p className="text-2xl font-black text-black">{cityData.avgRent}</p>
                      <p className="text-[10px] text-gray-400 uppercase font-bold">Avg Rent</p>
                    </div>
                    <div>
                      <p className="text-2xl font-black text-black">4.49%</p>
                      <p className="text-[10px] text-gray-400 uppercase font-bold">Best Fixed Rate</p>
                    </div>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2 - REALTORS & PRE-CONSTRUCTION */}
      <section className="py-24 bg-gray-50 border-b border-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-5xl font-black text-black mb-16 uppercase tracking-tighter text-center">
            Realtors & Pre-Construction in {cityData.name}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-10 rounded-2xl shadow-sm border border-gray-100">
               <Building2 size={32} className="text-black mb-6" />
               <h3 className="text-xl font-black mb-4 uppercase tracking-tight">Platinum Projects</h3>
               <p className="text-gray-500 text-sm mb-8">{cityData.realtorInsights}</p>
               <Link to={`/pre-construction-condos-${cityData.slug}`} className="text-black font-black uppercase text-[10px] tracking-[0.2em] flex items-center gap-2 hover:underline">
                 View Projects <ArrowRight size={14} />
               </Link>
            </div>
            <div className="bg-white p-10 rounded-2xl shadow-sm border border-gray-100">
               <Zap size={32} className="text-black mb-6" />
               <h3 className="text-xl font-black mb-4 uppercase tracking-tight">Investor Deals</h3>
               <p className="text-gray-500 text-sm mb-8">Exclusive access to off-market and high-ROI opportunities in {cityData.name}.</p>
               <Link to="/listings" className="text-black font-black uppercase text-[10px] tracking-[0.2em] flex items-center gap-2 hover:underline">
                 Resale Listings <ArrowRight size={14} />
               </Link>
            </div>
            <div className="bg-white p-10 rounded-2xl shadow-sm border border-gray-100">
               <TrendingUp size={32} className="text-black mb-6" />
               <h3 className="text-xl font-black mb-4 uppercase tracking-tight">Market Growth</h3>
               <p className="text-gray-500 text-sm mb-8">{cityData.marketTrend}</p>
               <Link to="/learn" className="text-black font-black uppercase text-[10px] tracking-[0.2em] flex items-center gap-2 hover:underline">
                 Market Insights <ArrowRight size={14} />
               </Link>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3 - LEGAL, RENO & MANAGEMENT */}
      <section className="py-24 bg-white border-b border-gray-100">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
             <div className="flex flex-col md:flex-row gap-12 items-center mb-16">
               <div className="md:w-1/2">
                 <h2 className="text-3xl font-black mb-6 uppercase tracking-tight">Legal & Closings</h2>
                 <p className="text-gray-600 mb-6">{cityData.legalInsights}</p>
                 <div className="flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-widest">
                   <Scale size={16} /> Independent Vetted Law Firms
                 </div>
               </div>
               <div className="md:w-1/2">
                 <h2 className="text-3xl font-black mb-6 uppercase tracking-tight">Renovation Strategy</h2>
                 <p className="text-gray-600 mb-6">{cityData.renoInsights}</p>
                 <div className="flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-widest">
                   <Hammer size={16} /> Verified Build Partners
                 </div>
               </div>
             </div>
             <div className="bg-gray-100 p-8 rounded-2xl">
               <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest text-center leading-relaxed">
                 Mandatory Disclaimer: Real estate, legal, and renovation services are provided by independent third-party professionals. 
                 Mudit Chhura acts solely as a licensed mortgage agent and connects clients to these professionals as a value-added service in {cityData.name}.
               </p>
             </div>
          </div>
        </div>
      </section>

      {/* SECTION 5 - FAQs (Schema Required) */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-black text-black mb-12 uppercase tracking-tighter text-center">Frequently Asked Questions: Buying in {cityData.name}</h2>
            <div className="space-y-6">
              {cityData.faqs.map((faq, i) => (
                <div key={i} className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm">
                  <h3 className="text-lg font-black text-black mb-4">{faq.question}</h3>
                  <p className="text-gray-600 leading-relaxed text-sm">{faq.answer}</p>
                </div>
              ))}
            </div>
            <div className="mt-12 text-center">
              <Link to="/learn" className="text-black font-black uppercase text-xs tracking-widest hover:underline flex items-center justify-center gap-2">
                Visit Knowledge Hub <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA - ONE FORM */}
      <section className="py-32 bg-white">
        <div className="container mx-auto px-6">
           <div className="max-w-4xl mx-auto">
              <div className="text-center mb-16">
                 <h2 className="text-4xl md:text-6xl font-black text-black mb-4 uppercase tracking-tighter">Start My {cityData.name} Strategy</h2>
                 <p className="text-xl text-gray-500 font-medium">Connect with Mudit and the {cityData.name} Partner Network.</p>
              </div>
              <LeadForm 
                title={`IndiBrick ${cityData.name} Command Form`} 
                subtitle={`One form. One team. Complete solution in ${cityData.name}.`}
              />
           </div>
        </div>
      </section>
    </div>
  );
};

export default CityLandingPage;
