import React from 'react';
import { useParams } from 'react-router-dom';
import { PARTNERS } from '../constants';
import LeadForm from '../components/LeadForm';
import { Check } from 'lucide-react';

const PartnerLanding: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const partner = PARTNERS.find(p => p.id === id);

  if (!partner) {
    return <div className="p-20 text-center">Partner not found.</div>;
  }

  return (
    <div className="bg-white">
      {/* Co-Branded Hero */}
      <section className="bg-black text-white py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-center gap-12 text-center md:text-left">
             {/* Mudit */}
             <div className="flex flex-col items-center">
                <img src="https://picsum.photos/seed/face1/150/150" className="w-24 h-24 rounded-full border-4 border-white mb-4 grayscale" alt="Mudit Chhura" />
                <h3 className="font-bold text-lg">Mudit Chhura</h3>
                <p className="text-sm text-gray-400">Mortgage Agent</p>
                <p className="text-xs text-gray-500">Pineapple</p>
             </div>

             <div className="text-4xl text-gray-500 font-thin">+</div>

             {/* Partner */}
             <div className="flex flex-col items-center">
                <img src={partner.imageUrl} className="w-24 h-24 rounded-full border-4 border-white mb-4 grayscale" alt={partner.name} />
                <h3 className="font-bold text-lg">{partner.name}</h3>
                <p className="text-sm text-gray-400">{partner.role}</p>
                <p className="text-xs text-gray-500">{partner.brokerage}</p>
             </div>
          </div>
          
          <div className="text-center mt-12 max-w-2xl mx-auto">
            <h1 className="text-3xl md:text-5xl font-bold mb-6">Your Dream Team for Real Estate Success</h1>
            <p className="text-gray-300 text-lg">
              We have partnered to provide you with a seamless home buying experience. 
              Expert financing meets top-tier real estate service.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
             <h2 className="text-2xl font-bold text-black mb-6">Why Work With Us?</h2>
             <ul className="space-y-4">
               {[
                 'Pre-approval within 24 hours',
                 'Exclusive access to off-market listings',
                 'Strategic negotiation on your behalf',
                 'Seamless coordination between lender and agents'
               ].map((item, i) => (
                 <li key={i} className="flex items-center gap-3">
                   <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center shrink-0">
                     <Check size={14} />
                   </div>
                   <span className="text-gray-700">{item}</span>
                 </li>
               ))}
             </ul>

             <div className="mt-8 bg-gray-50 p-6 rounded-xl border border-gray-200">
               <h3 className="font-bold text-lg mb-2">About {partner.name}</h3>
               <p className="text-gray-600 text-sm leading-relaxed">
                 {partner.name} is a dedicated professional at {partner.brokerage}, committed to helping you find the perfect property. 
                 Together with Mudit Chhura's mortgage expertise, you are in safe hands.
               </p>
             </div>
          </div>

          <div>
            <LeadForm 
              title="Start Your Journey" 
              subtitle={`Connect with ${partner.name} and Mudit Chhura today.`}
              type="General" 
            />
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="bg-gray-100 py-6 border-t border-gray-200">
        <div className="container mx-auto px-4 text-center">
          <p className="text-[10px] text-gray-500">
            Marketing costs for this page are shared between Mudit Chhura (Pineapple) and {partner.name} ({partner.brokerage}). 
            Each professional is independently licensed and responsible for their own services.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PartnerLanding;