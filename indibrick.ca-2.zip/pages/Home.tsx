import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BadgeCheck, Phone, CheckCircle, ShieldCheck, Zap, ExternalLink, Users, Scale, Hammer, Building2 } from 'lucide-react';
import { useRates } from '../RateContext';
import { useAdmin } from '../AdminContext';
import LeadForm from '../components/LeadForm';

const Home: React.FC = () => {
  const { rates } = useRates();
  const { siteSettings } = useAdmin();

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col">
      
      {/* SECTION 1: THE COMMAND CENTER (Hero) */}
      <section className="relative h-screen min-h-[700px] flex items-center bg-black overflow-hidden">
        {/* Cinematic Background (Simulated Video with optimized Image) */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1920&q=80" 
            alt="Luxury Home Interior" 
            className="w-full h-full object-cover opacity-60 grayscale"
          />
          <div className="absolute inset-0 cinematic-gradient"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl space-y-8">
            <div className="inline-flex items-center gap-3 glass border border-white/20 px-4 py-2 rounded-full text-white text-xs font-black uppercase tracking-widest animate-pulse">
              <Zap size={14} className="text-white" /> Financing Your Home Ownership Journey
            </div>
            
            <h1 className="text-5xl md:text-8xl font-black text-white leading-[1.1] tracking-tighter">
              More Than a Mortgage.<br/>
              <span className="text-gray-400">Your Complete Real Estate Ecosystem.</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-300 font-medium max-w-2xl leading-relaxed">
              Financing • Real Estate • Legal • Renovation<br/>
              <span className="font-bold text-white">One Team. One Strategy. One Solution.</span>
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5 pt-4">
              <a 
                href="https://gopineapple.ca/muditchhura/preapproval" 
                target="_blank"
                rel="noopener noreferrer"
                className="group px-10 py-5 bg-white text-black font-black uppercase text-sm tracking-widest rounded-full hover:bg-gray-200 transition-all flex items-center justify-center gap-3 shadow-2xl"
              >
                Start My Pre-Approval <ArrowRight size={18} className="group-hover:translate-x-1 transition" />
              </a>
              <button 
                onClick={() => scrollToSection('concierge')}
                className="px-10 py-5 bg-transparent border border-white/30 text-white font-black uppercase text-sm tracking-widest rounded-full hover:bg-white/10 transition-all backdrop-blur-sm"
              >
                Explore the Network
              </button>
            </div>

            {/* Compliance Identity Rule - Hero */}
            <div className="pt-12 flex items-center gap-4 text-white/50 border-t border-white/10 w-fit">
              <div className="text-left">
                <p className="text-xs font-black uppercase tracking-widest text-white">Mudit Chhura</p>
                <p className="text-[10px] uppercase font-bold">Mortgage Agent Level 1 • License # M25003057</p>
                <p className="text-[10px] uppercase font-bold">Brokerage: Pineapple • License # 12830</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: LIVE RATES TICKER / WIDGET */}
      <div className="bg-black border-y border-white/10 py-4 overflow-hidden sticky top-24 z-40 backdrop-blur-lg">
        {siteSettings.useExternalRatesWidget && siteSettings.ratesWidgetUrl ? (
          /* GO PINEAPPLE EXTERNAL WIDGET MODE */
          <div className="container mx-auto px-6 flex flex-col items-center">
             <div className="w-full flex justify-between items-center mb-2 px-2">
               <span className="text-gray-500 font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
                  <ShieldCheck size={12} /> Verified Pineapple Live Data
               </span>
               <a href="https://gopineapple.ca/muditchhura/rates" target="_blank" className="text-white font-black text-[10px] uppercase tracking-widest hover:underline flex items-center gap-1">
                 Full Table <ExternalLink size={10} />
               </a>
             </div>
             <div className="w-full h-16 bg-white/5 rounded-xl overflow-hidden border border-white/10 relative group">
                <iframe 
                  src={siteSettings.ratesWidgetUrl} 
                  className="w-full h-[500%] absolute -top-[200%] pointer-events-none scale-[0.35] origin-center opacity-80"
                  title="GoPineapple Rates Widget"
                  scrolling="no"
                />
                <div className="absolute inset-0 bg-transparent z-10"></div>
             </div>
          </div>
        ) : (
          /* INTERNAL TICKER FALLBACK */
          <div className="whitespace-nowrap flex">
            <div className="inline-block animate-ticker">
              <div className="flex items-center gap-16 px-8">
                <div className="flex items-center gap-3">
                  <span className="text-gray-500 font-black text-xs uppercase tracking-widest">Today's Best Rates</span>
                  <div className="h-4 w-px bg-white/20"></div>
                </div>
                {rates.map((rate) => (
                  <div key={rate.id} className="flex items-center gap-4">
                    <span className="text-white text-sm font-bold uppercase">{rate.term}</span>
                    <span className="text-white text-lg font-black">{rate.rate.toFixed(2)}%</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-black ${rate.type === 'Fixed' ? 'bg-white text-black' : 'bg-gray-800 text-gray-400'}`}>
                      {rate.type}
                    </span>
                  </div>
                ))}
                <a 
                  href="https://gopineapple.ca/muditchhura/rates" 
                  target="_blank" 
                  className="flex items-center gap-2 text-white font-black uppercase text-[10px] tracking-widest border border-white/20 px-3 py-1 rounded hover:bg-white hover:text-black transition"
                >
                  Official Rates <ExternalLink size={12} />
                </a>
                <span className="text-[10px] text-gray-500 uppercase font-bold italic">Rates subject to qualification (OAC). Terms apply.</span>
              </div>
            </div>
            {/* Repeat for seamless loop */}
            <div className="inline-block animate-ticker">
              <div className="flex items-center gap-16 px-8">
                <div className="flex items-center gap-3">
                  <span className="text-gray-500 font-black text-xs uppercase tracking-widest">Today's Best Rates</span>
                  <div className="h-4 w-px bg-white/20"></div>
                </div>
                {rates.map((rate) => (
                  <div key={rate.id + '_repeat'} className="flex items-center gap-4">
                    <span className="text-white text-sm font-bold uppercase">{rate.term}</span>
                    <span className="text-white text-lg font-black">{rate.rate.toFixed(2)}%</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-black ${rate.type === 'Fixed' ? 'bg-white text-black' : 'bg-gray-800 text-gray-400'}`}>
                      {rate.type}
                    </span>
                  </div>
                ))}
                <a 
                  href="https://gopineapple.ca/muditchhura/rates" 
                  target="_blank" 
                  className="flex items-center gap-2 text-white font-black uppercase text-[10px] tracking-widest border border-white/20 px-3 py-1 rounded hover:bg-white hover:text-black transition"
                >
                  Official Rates <ExternalLink size={12} />
                </a>
                <span className="text-[10px] text-gray-500 uppercase font-bold italic">Rates subject to qualification (OAC). Terms apply.</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SECTION 3: THE CONCIERGE (360° SERVICES GRID) */}
      <section id="concierge" className="py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl md:text-6xl font-black text-black mb-6 tracking-tighter uppercase">The 360° Property Solution</h2>
            <div className="h-1.5 w-24 bg-black mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                title: 'Mortgage Strategy',
                icon: <Zap size={32} />,
                items: ['Purchase & Renewals', 'Refinancing', 'Private Lending', 'Investment Equity'],
                link: '/services'
              },
              {
                title: 'Real Estate Access',
                icon: <Building2 size={32} />,
                items: ['Trusted Realtors', 'Pre-Construction Access', 'Investment Analysis', 'Market Insights'],
                link: '/listings'
              },
              {
                title: 'Legal Protection',
                icon: <Scale size={32} />,
                items: ['Real Estate Lawyers', 'Closing Coordination', 'Commercial Closings', 'Estate Planning'],
                link: '/services'
              },
              {
                title: 'Property & Reno',
                icon: <Hammer size={32} />,
                items: ['Reno Financing', 'Vetted Contractors', 'Home Addition Loans', 'Project Management'],
                link: '/renovation-financing'
              }
            ].map((card, i) => (
              <div key={i} className="group p-10 bg-gray-50 border border-gray-100 rounded-2xl hover:bg-black hover:border-black transition-all duration-500 flex flex-col h-full shadow-sm hover:shadow-2xl">
                <div className="mb-8 text-black group-hover:text-white transition-colors">{card.icon}</div>
                <h3 className="text-2xl font-black text-black group-hover:text-white mb-6 uppercase tracking-tight transition-colors">{card.title}</h3>
                <ul className="space-y-3 mb-12 flex-grow">
                  {card.items.map((item, j) => (
                    <li key={j} className="text-gray-500 group-hover:text-gray-400 text-sm font-bold flex items-center gap-2 transition-colors">
                      <div className="w-1 h-1 bg-black group-hover:bg-white rounded-full transition-colors"></div>
                      {item}
                    </li>
                  ))}
                </ul>
                <Link to={card.link} className="inline-flex items-center gap-2 text-black group-hover:text-white font-black text-xs uppercase tracking-widest transition-colors hover:underline">
                  Connect with Expert <ArrowRight size={14} />
                </Link>
              </div>
            ))}
          </div>

          <div className="mt-20 p-8 border-t border-gray-100 text-center">
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest max-w-2xl mx-auto leading-relaxed">
              Real estate, legal, renovation, and property management services are provided by independent third-party professionals. 
              Mudit Chhura acts solely as a licensed mortgage agent and connects clients to these professionals as a value-added service.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 4: TRUST & PARTNER NETWORK */}
      <section className="py-32 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row items-center gap-20">
            <div className="lg:w-1/2 space-y-8">
              <h2 className="text-4xl md:text-5xl font-black text-black tracking-tighter uppercase leading-none">
                We Don’t Just Close the Deal.<br/>
                <span className="text-gray-400">We Support the Home.</span>
              </h2>
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-3">
                  <div className="w-12 h-12 bg-black text-white rounded-xl flex items-center justify-center shadow-lg"><CheckCircle size={24} /></div>
                  <h4 className="font-black text-black uppercase text-sm tracking-widest">End-to-End Guidance</h4>
                  <p className="text-sm text-gray-500 leading-relaxed">From initial search to renovation quotes, we are by your side through every structural phase.</p>
                </div>
                <div className="space-y-3">
                  <div className="w-12 h-12 bg-black text-white rounded-xl flex items-center justify-center shadow-lg"><Users size={24} /></div>
                  <h4 className="font-black text-black uppercase text-sm tracking-widest">24/7 Advisor Support</h4>
                  <p className="text-sm text-gray-500 leading-relaxed">Your home financing strategy evolves. We provide ongoing advisory long after you get your keys.</p>
                </div>
              </div>
            </div>
            <div className="lg:w-1/2">
              <div className="bg-white p-12 rounded-3xl shadow-xl border border-gray-100">
                 <h3 className="text-xl font-black text-black mb-8 uppercase tracking-widest text-center">Our Partner Network</h3>
                 <div className="grid grid-cols-3 gap-10 opacity-40 hover:opacity-100 transition-opacity">
                    {[1,2,3,4,5,6].map(i => (
                      <div key={i} className="flex flex-col items-center gap-2">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                           <ShieldCheck size={32} className="text-gray-300" />
                        </div>
                        <span className="text-[10px] font-black uppercase text-gray-400 tracking-tighter">Verified Firm</span>
                      </div>
                    ))}
                 </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 5: THE “ONE FORM” LEAD ENGINE */}
      <section id="contact" className="py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-6xl font-black text-black mb-4 uppercase tracking-tighter">How Can We Help?</h2>
              <p className="text-xl text-gray-500 font-medium">Select your goal and we will match you with the right specialist.</p>
            </div>
            <LeadForm 
              title="IndiBrick Command Form" 
              subtitle="The fastest way to connect with Mudit and the Partner Network."
            />
          </div>
        </div>
      </section>

      {/* STICKY BOTTOM ACTIONS (Mobile) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 flex border-t border-white/10 shadow-2xl">
         <a href="tel:4372416392" className="flex-1 bg-white text-black font-black uppercase tracking-widest text-[10px] py-5 flex items-center justify-center gap-2">
           <Phone size={14} /> Call Advisor
         </a>
         <a href="https://gopineapple.ca/muditchhura/preapproval" target="_blank" className="flex-1 bg-black text-white font-black uppercase tracking-widest text-[10px] py-5 flex items-center justify-center gap-2">
           Apply Now
         </a>
      </div>

    </div>
  );
};

export default Home;
