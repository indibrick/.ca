import React from 'react';
import MortgageCalculator from '../components/MortgageCalculator';
import TriggerRateCalculator from '../components/TriggerRateCalculator';

const Tools: React.FC = () => {
  return (
    <div className="bg-gray-50 min-h-screen py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-10 text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Financial Tools</h1>
          <p className="text-slate-600 text-lg">
            Plan your purchase with confidence using our suite of calculators.
          </p>
        </div>

        <div className="max-w-5xl mx-auto space-y-12">
          <MortgageCalculator />
          
          <TriggerRateCalculator />

          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <h3 className="text-xl font-bold text-gray-900 mb-4">More Calculators Coming Soon</h3>
            <div className="flex flex-wrap justify-center gap-4">
              <span className="px-4 py-2 bg-gray-100 rounded-lg text-gray-500">Affordability</span>
              <span className="px-4 py-2 bg-gray-100 rounded-lg text-gray-500">CMHC Insurance</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Tools;