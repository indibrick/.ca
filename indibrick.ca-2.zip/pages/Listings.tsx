import React, { useState } from 'react';
import { PROPERTIES } from '../constants';
import ListingCard from '../components/ListingCard';
import { Filter } from 'lucide-react';

const Listings: React.FC = () => {
  const [filterType, setFilterType] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProperties = PROPERTIES.filter(p => {
    const matchesType = filterType === 'All' || p.type === filterType;
    const matchesSearch = p.city.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.address.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
        <div>
           <h1 className="text-3xl font-bold text-slate-900 mb-2">Property Listings</h1>
           <p className="text-slate-600">Explore resale homes, investments, and rental opportunities in the GTA.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
          {/* Simple Search */}
          <div className="relative">
             <input 
               type="text" 
               placeholder="Search City or Address..." 
               className="pl-4 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary outline-none w-full sm:w-64"
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
             />
          </div>

          {/* Simple Filter */}
          <div className="relative">
             <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
               <Filter size={16} className="text-gray-500" />
             </div>
             <select 
               className="pl-10 pr-8 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary outline-none appearance-none bg-white w-full sm:w-48"
               value={filterType}
               onChange={(e) => setFilterType(e.target.value)}
             >
               <option value="All">All Types</option>
               <option value="Detached">Detached</option>
               <option value="Semi-Detached">Semi-Detached</option>
               <option value="Townhouse">Townhouse</option>
               <option value="Condo">Condo</option>
             </select>
          </div>
        </div>
      </div>

      {filteredProperties.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProperties.map((prop) => (
            <ListingCard key={prop.id} property={prop} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-gray-50 rounded-xl">
          <p className="text-gray-500 text-lg">No properties found matching your criteria.</p>
          <button 
            onClick={() => {setFilterType('All'); setSearchTerm('')}}
            className="mt-4 text-primary font-semibold hover:underline"
          >
            Clear Filters
          </button>
        </div>
      )}
    </div>
  );
};

export default Listings;