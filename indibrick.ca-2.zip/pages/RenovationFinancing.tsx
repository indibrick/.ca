import React from 'react';
import LeadForm from '../components/LeadForm';
import { Hammer, PaintBucket, Shovel, Home, CheckCircle } from 'lucide-react';

const RenovationFinancing: React.FC = () => {
  const trades = [
    { name: 'Kitchen & Bath', icon: <Home size={32} />, desc: 'Full remodels increasing property value.' },
    { name: 'Basement & Legal Suites', icon: <Hammer size={32} />, desc: 'Create rental income potential.' },
    { name: 'Flooring & Painting', icon: <PaintBucket size={32} />, desc: 'High-impact cosmetic upgrades.' },
    { name: 'Landscaping', icon: <Shovel size={32} />, desc: 'Curb appeal and outdoor living.' },
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="bg-black text-white py-20 relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight">
            Turn a 'Fixer-Upper' into Your Dream Home.
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            We specialize in "Purchase Plus Improvement" mortgages and connect you with trusted contractors who understand bank-approved quotes.
          </p>
          <button 
            onClick={() => document.getElementById('quote-form')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-gray-200 transition"
          >
            Start Your Project
          </button>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-black mb-8 text-center">Why Combine Financing & Renovations?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <span className="bg-black text-white w-8 h-8 rounded-full flex items-center justify-center text-sm">1</span>
                  Purchase Plus Improvements
                </h3>
                <p className="text-gray-600 mb-4">
                  Did you know you can borrow up to $40,000 (or 20% of the home price) extra to renovate immediately upon closing?
                  Instead of using high-interest credit cards, roll the renovation costs into your low-interest mortgage payment.
                </p>
              </div>
              
              <div>
                 <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <span className="bg-black text-white w-8 h-8 rounded-full flex items-center justify-center text-sm">2</span>
                  The "Quote" Hurdle
                </h3>
                <p className="text-gray-600 mb-4">
                  Banks require strict, fixed-price quotes from contractors before they approve the loan. 
                  Most contractors don't know how to format this correctly. <strong>Our partners do.</strong>
                  They provide exactly what the lender needs to say "Yes".
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Renovation Squad Grid */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-3xl font-bold text-black mb-12 text-center">The Renovation Squad</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {trades.map((trade, idx) => (
            <div key={idx} className="bg-white p-6 rounded-xl shadow-md border border-gray-100 text-center hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gray-100 text-black rounded-full flex items-center justify-center mx-auto mb-4">
                {trade.icon}
              </div>
              <h3 className="text-lg font-bold mb-2">{trade.name}</h3>
              <p className="text-gray-500 text-sm">{trade.desc}</p>
            </div>
          ))}
        </div>
        
        <div className="bg-black text-white p-8 rounded-2xl text-center max-w-3xl mx-auto">
           <h3 className="text-2xl font-bold mb-4">Need a Contractor?</h3>
           <p className="mb-6">Don't risk your financing with unverified quotes. Use our vetted network.</p>
           <button 
             onClick={() => document.getElementById('quote-form')?.scrollIntoView({ behavior: 'smooth' })}
             className="bg-white text-black px-6 py-2 rounded-lg font-bold hover:bg-gray-200 transition"
           >
             Request a Quote
           </button>
        </div>
      </section>

      {/* Lead Form */}
      <section id="quote-form" className="py-16 bg-gray-100">
        <div className="container mx-auto px-4 max-w-2xl">
          {/* Corrected 'type' prop from 'Renovation' to 'Contractor' to satisfy LeadFormProps type constraints */}
          <LeadForm 
            type="Contractor" 
            title="Request a Quote & Financing Check" 
            subtitle="Tell us about your project. If you need financing, we'll handle the mortgage side first."
          />
        </div>
      </section>

      {/* Mandatory Disclaimer */}
      <section className="py-8 bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 text-center">
          <p className="text-xs text-gray-500 max-w-4xl mx-auto leading-relaxed">
            <strong>Legal Disclaimer:</strong> Contractors and tradespeople listed or referred via this platform are independent third-party professionals. 
            Pineapple and Mudit Chhura do not warrant or guarantee their work, timelines, or pricing. 
            Referrals are provided as a courtesy to assist clients with "Purchase Plus Improvement" mortgage documentation requirements. 
            Clients are strictly encouraged to conduct their own due diligence, check references, and verify insurance before hiring any tradesperson.
          </p>
        </div>
      </section>
    </div>
  );
};

export default RenovationFinancing;