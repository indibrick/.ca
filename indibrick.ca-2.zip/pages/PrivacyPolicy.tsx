import React from 'react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl font-bold text-black mb-8">Privacy Policy</h1>
        
        <div className="prose max-w-none text-gray-700 space-y-6">
          <p className="font-bold">Last Updated: October 2023</p>

          <section>
            <h2 className="text-2xl font-bold text-black mb-4">1. Introduction</h2>
            <p>
              Mudit Chhura ("Mortgage Agent") operating under the license of Pineapple ("Brokerage") acts as a data controller. 
              We are committed to protecting your personal information in accordance with PIPEDA (Personal Information Protection and Electronic Documents Act) and CASL (Canada's Anti-Spam Legislation).
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-black mb-4">2. Information Collection</h2>
            <p>
              We collect information you provide directly to us, such as your name, email address, phone number, and financial details required for mortgage applications. 
              When you use our lead forms, we may ask for your consent to share this data with specific partners (Real Estate Agents or Lawyers).
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-black mb-4">3. Data Sharing & Partners</h2>
            <p>
              We do not sell your data. We only share your information with trusted third parties (such as lenders, real estate agents, or lawyers) if you explicitly request a referral or if it is necessary to process your mortgage application. 
              All partners are independently responsible for their own privacy practices.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-black mb-4">4. Consent & CASL</h2>
            <p>
              By checking the consent box on our forms, you agree to receive electronic communications from us and our selected partners regarding your home buying journey. 
              You may unsubscribe from these communications at any time by clicking the "unsubscribe" link in our emails.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-black mb-4">5. Contact Us</h2>
            <p>
              If you have questions about this policy or wish to withdraw your consent, please contact us at hello@indibrick.ca or 123 Financial District Blvd, Toronto, ON.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;