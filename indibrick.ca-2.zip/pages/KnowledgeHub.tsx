import React from 'react';
import { Link } from 'react-router-dom';
import { KNOWLEDGE_BASE } from '../data/knowledgeBase';
import { BookOpen, ArrowRight, User, MapPin, Home, Hammer, Scale, Divide, Calculator } from 'lucide-react';

const KnowledgeHub: React.FC = () => {
  // Group articles by category
  const categories = Array.from(new Set(KNOWLEDGE_BASE.map(a => a.category)));
  
  const getIcon = (cat: string) => {
      if (cat.includes('Borrower')) return <User size={24} />;
      if (cat.includes('Local')) return <MapPin size={24} />;
      if (cat.includes('Property')) return <Home size={24} />;
      if (cat.includes('Renovation')) return <Hammer size={24} />;
      if (cat.includes('Legal')) return <Scale size={24} />;
      if (cat.includes('Comparisons')) return <Divide size={24} />;
      return <Calculator size={24} />;
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Header */}
      <section className="bg-black text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6">
             <BookOpen size={16} /> Mortgage Knowledge Hub
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-6">Master Your Mortgage</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Expert answers to your toughest questions. From "Stated Income" to "Private Lending," we break it down simply.
          </p>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((cat) => {
             const articles = KNOWLEDGE_BASE.filter(a => a.category === cat);
             return (
               <div key={cat} className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 hover:shadow-xl transition-shadow">
                 <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-lg bg-black text-white flex items-center justify-center">
                        {getIcon(cat)}
                    </div>
                    <h2 className="text-xl font-bold text-black">{cat}</h2>
                 </div>
                 
                 <ul className="space-y-4">
                   {articles.map(article => (
                     <li key={article.id}>
                       <Link 
                         to={`/learn/${article.slug}`}
                         className="flex items-start justify-between gap-2 group"
                       >
                         <span className="text-gray-700 text-sm font-medium group-hover:text-black group-hover:underline leading-snug">
                           {article.title}
                         </span>
                         <ArrowRight size={14} className="shrink-0 mt-1 text-gray-400 group-hover:text-black" />
                       </Link>
                     </li>
                   ))}
                   <li className="pt-2">
                     <span className="text-xs text-gray-400 uppercase font-bold tracking-wider">
                       + More articles coming soon
                     </span>
                   </li>
                 </ul>
               </div>
             );
          })}
        </div>
      </section>

      {/* Search CTA */}
      <section className="bg-gray-50 py-16 border-t border-gray-200">
         <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl font-bold text-black mb-4">Can't find what you're looking for?</h2>
            <p className="text-gray-600 mb-8">Our team is ready to answer your specific scenario.</p>
            <Link to="/contact" className="inline-block bg-black text-white px-8 py-3 rounded-lg font-bold hover:bg-gray-800 transition">
              Ask an Expert
            </Link>
         </div>
      </section>
    </div>
  );
};

export default KnowledgeHub;
