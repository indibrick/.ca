import React, { useState } from 'react';
import { PROPERTIES } from '../constants';
import ListingCard from '../components/ListingCard';
import LeadForm from '../components/LeadForm';
import { Lock, FileText, CheckCircle } from 'lucide-react';

const PreConstruction: React.FC = () => {
  const [unlocked, setUnlocked] = useState(false);
  const preConProps = PROPERTIES.filter(p => p.purpose === 'Pre-Construction');

  const handleUnlock = () => {
    // In a real app, this would be triggered by LeadForm's onSuccess callback
    setUnlocked(true);
  };

  return (
    <div>
      <div className="bg-black text-white py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-black mb-8">Platinum Access</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Beat the public. Access Day 1 floor plans, investor pricing, and special builders' incentives across the GTA.
          </p>
          <div className="flex justify-center gap-4">
             <span className="bg-white/10 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-2">
               <CheckCircle size={14} className="text-white" /> Tarion Verified
             </span>
             <span className="bg-white/10 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-2">
               <CheckCircle size={14} className="text-white" /> Deposit structures
             </span>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2 space-y-12">
            <h2 className="text-3xl font-black text-black mb-8">Current Active Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {preConProps.map(p => (
                <div key={p.id} className="relative group">
                  <ListingCard property={p} />
                  {!unlocked && (
                    <div className="absolute inset-x-0 bottom-4 px-4">
                      <button onClick={handleUnlock} className="w-full bg-white/95 backdrop-blur-sm text-black py-3 rounded-lg font-bold shadow-xl border border-gray-100 flex items-center justify-center gap-2">
                         <Lock size={16} /> Unlock Brochure
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className={`transition-all duration-700 ${unlocked ? 'opacity-100 translate-y-0' : 'opacity-20 blur-sm grayscale pointer-events-none'}`}>
               <h3 className="text-2xl font-black mb-6">Platinum Investor Packages</h3>
               <div className="space-y-4">
                 {[1, 2, 3].map(i => (
                   <div key={i} className="bg-white p-6 rounded-2xl border border-gray-200 flex justify-between items-center hover:border-black transition cursor-pointer group shadow-sm">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center group-hover:bg-black group-hover:text-white transition">
                           <FileText size={24} />
                        </div>
                        <div>
                          <h4 className="font-bold text-black">Project Floorplans & ROI Analytics - Tier {i}</h4>
                          <p className="text-xs text-gray-500 uppercase font-bold tracking-widest">Confidential • 1.2MB PDF</p>
                        </div>
                      </div>
                      <button className="bg-gray-100 px-4 py-2 rounded-lg font-bold text-xs uppercase group-hover:bg-black group-hover:text-white transition">Download</button>
                   </div>
                 ))}
               </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-24">
              {!unlocked ? (
                <LeadForm 
                  type="Pre-Con" 
                  title="Unlock Investor Packs" 
                  subtitle="Submit the form to gain instant access to confidential floor plans and builder pricing lists." 
                />
              ) : (
                <div className="bg-black text-white p-10 rounded-3xl text-center">
                   <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle size={40} className="text-white" />
                   </div>
                   <h3 className="text-2xl font-black mb-4">Access Granted</h3>
                   <p className="text-gray-400 mb-8 leading-relaxed">You now have access to all gated project brochures. Our Platinum Advisor will reach out shortly to discuss your investment strategy.</p>
                   <button onClick={() => setUnlocked(false)} className="text-xs font-bold uppercase tracking-widest opacity-50 hover:opacity-100">Lock Content</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreConstruction;