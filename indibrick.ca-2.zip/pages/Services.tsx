import React from 'react';
import { SERVICES } from '../constants';
import { BadgeCheck, Users, Building2, Hammer, ArrowRight, HardHat } from 'lucide-react';
import { Link } from 'react-router-dom';

const Services: React.FC = () => {
  return (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
           <h1 className="text-4xl font-bold text-black mb-4">Our Services</h1>
           <p className="text-xl text-gray-600 max-w-2xl mx-auto">
             IndiBrick provides a comprehensive ecosystem for all your real estate needs.
           </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {SERVICES.map((service) => (
             <div key={service.id} className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 flex flex-col md:flex-row gap-6">
               <div className="shrink-0">
                 <div className="w-16 h-16 bg-gray-100 text-black rounded-2xl flex items-center justify-center">
                    {service.iconName === 'BadgeDollarSign' && <BadgeCheck size={32} />}
                    {service.iconName === 'Users' && <Users size={32} />}
                    {service.iconName === 'Building2' && <Building2 size={32} />}
                    {service.iconName === 'Hammer' && <Hammer size={32} />}
                    {service.iconName === 'HardHat' && <HardHat size={32} />}
                 </div>
               </div>
               <div>
                 <h3 className="text-2xl font-bold text-black mb-3">{service.title}</h3>
                 <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                 <Link 
                   to={service.link} 
                   className="inline-flex items-center text-black font-bold hover:text-gray-600 transition"
                 >
                   Learn More <ArrowRight size={18} className="ml-2" />
                 </Link>
               </div>
             </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Services;