import React, { useState } from 'react';
import { Users, FileText, Settings, LogOut, TrendingUp, Edit2, Trash2, X, Save, Plus, Newspaper, Shield, Database, CheckCircle, RefreshCcw, Download, Link as LinkIcon } from 'lucide-react';
import { useRates } from '../RateContext';
import { useAdmin } from '../AdminContext';
import { MortgageRate, Builder } from '../types';

const Admin: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'CRM' | 'Rates' | 'News' | 'Builders' | 'Bulk' | 'Settings'>('CRM');
  const { rates, addRate, updateRate, deleteRate } = useRates();
  const { 
    siteSettings, updateSettings, newsArticles, approveNews, deleteNews, fetchNews, 
    leads, updateLeadStatus, builders, addBuilder, bulkUploadProperties 
  } = useAdmin();
  
  // Rate Editing State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [rateForm, setRateForm] = useState<Partial<MortgageRate>>({ term: '', rate: 0, type: 'Fixed' });

  // Builder Form State
  const [builderForm, setBuilderForm] = useState<Partial<Builder>>({
    name: '', licenseNumber: '', officeLocation: '', rating: 5
  });

  const handleEditClick = (rate: MortgageRate) => {
    setEditingId(rate.id);
    setRateForm({ ...rate });
  };

  const handleSaveRate = () => {
    if (!rateForm.term || !rateForm.rate) return;
    if (editingId) updateRate(editingId, rateForm);
    else addRate(rateForm as Omit<MortgageRate, 'id'>);
    setEditingId(null);
    setRateForm({ term: '', rate: 0, type: 'Fixed' });
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-black text-white hidden md:flex flex-col shrink-0">
        <div className="p-6 border-b border-gray-800 flex items-center gap-3">
           <svg viewBox="0 0 100 100" className="w-8 h-8 text-white" fill="currentColor"><rect x="10" y="5" width="80" height="18" rx="2" /><rect x="10" y="28" width="38" height="18" rx="2" /><rect x="52" y="28" width="38" height="18" rx="2" /><rect x="10" y="51" width="80" height="18" rx="2" /><rect x="10" y="74" width="38" height="18" rx="2" /><rect x="52" y="74" width="38" height="18" rx="2" /></svg>
           <span className="text-xl font-black uppercase tracking-tighter">INDIBRICK</span>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          {[
            { id: 'CRM', icon: Users, label: 'Lead CRM' },
            { id: 'Rates', icon: TrendingUp, label: 'Rates' },
            { id: 'News', icon: Newspaper, label: 'News Scraper' },
            { id: 'Builders', icon: Shield, label: 'Builders' },
            { id: 'Bulk', icon: Database, label: 'Bulk Import' },
            { id: 'Settings', icon: Settings, label: 'Site Controls' },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition font-medium ${activeTab === tab.id ? 'bg-white text-black' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
            >
              <tab.icon size={20} /> {tab.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-800">
           <button className="flex items-center gap-2 text-gray-500 hover:text-white transition text-sm"><LogOut size={16} /> Logout</button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto">
        <div className="p-8 max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-10">
            <h1 className="text-3xl font-black text-black">{activeTab} Management</h1>
            <div className="text-sm text-gray-500">Welcome back, Mudit</div>
          </div>

          {/* TAB: CRM */}
          {activeTab === 'CRM' && (
            <div className="space-y-6">
               <div className="grid grid-cols-4 gap-4 mb-8">
                 <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                   <p className="text-xs text-gray-500 font-bold uppercase mb-1">New Leads</p>
                   <p className="text-2xl font-black text-black">{leads.filter(l => l.status === 'New').length}</p>
                 </div>
                 <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                   <p className="text-xs text-gray-500 font-bold uppercase mb-1">In Progress</p>
                   <p className="text-2xl font-black text-black">{leads.filter(l => l.status === 'In-Progress').length}</p>
                 </div>
                 <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                   <p className="text-xs text-gray-500 font-bold uppercase mb-1">Closed Won</p>
                   <p className="text-2xl font-black text-black">{leads.filter(l => l.status === 'Closed').length}</p>
                 </div>
                 <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                   <p className="text-xs text-gray-500 font-bold uppercase mb-1">Conversion %</p>
                   <p className="text-2xl font-black text-black">12.4%</p>
                 </div>
               </div>
               <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                 <table className="w-full text-left">
                   <thead className="bg-gray-50 border-b border-gray-200 text-xs text-gray-500 font-bold uppercase">
                     <tr>
                       <th className="px-6 py-4">Lead Info</th>
                       <th className="px-6 py-4">Service</th>
                       <th className="px-6 py-4">Status</th>
                       <th className="px-6 py-4">Assigned To</th>
                       <th className="px-6 py-4">Actions</th>
                     </tr>
                   </thead>
                   <tbody className="divide-y divide-gray-100">
                     {leads.map(lead => (
                       <tr key={lead.id} className="hover:bg-gray-50 transition">
                         <td className="px-6 py-4">
                           <div className="font-bold text-black">{lead.name}</div>
                           <div className="text-xs text-gray-500">{lead.email}</div>
                         </td>
                         <td className="px-6 py-4 text-sm font-medium">{lead.serviceNeeded}</td>
                         <td className="px-6 py-4">
                           <select 
                             className="text-xs font-bold px-2 py-1 rounded bg-gray-100 border-none outline-none"
                             value={lead.status}
                             onChange={(e) => updateLeadStatus(lead.id, e.target.value as any)}
                           >
                             {['New', 'Contacted', 'In-Progress', 'Closed', 'Dead'].map(s => <option key={s} value={s}>{s}</option>)}
                           </select>
                         </td>
                         <td className="px-6 py-4 text-sm text-gray-600">Mudit C.</td>
                         <td className="px-6 py-4"><button className="text-black font-bold hover:underline">Details</button></td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </div>
          )}

          {/* TAB: NEWS SCRAPER */}
          {activeTab === 'News' && (
            <div className="space-y-8">
               <div className="bg-black text-white p-8 rounded-2xl flex justify-between items-center">
                 <div>
                   <h2 className="text-2xl font-bold mb-2">News Scraper Approval Queue</h2>
                   <p className="text-gray-400">Automated fetching from CBC, Financial Post, and CREA.</p>
                 </div>
                 <button onClick={fetchNews} className="bg-white text-black px-6 py-3 rounded-lg font-bold flex items-center gap-2 hover:bg-gray-200 transition">
                    <RefreshCcw size={18} /> Fetch Latest
                 </button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {newsArticles.filter(a => a.status === 'pending').map(article => (
                   <div key={article.id} className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm relative group">
                      <div className="flex justify-between items-start mb-4">
                        <span className="text-[10px] bg-gray-100 px-2 py-1 rounded-full font-bold uppercase text-gray-500">{article.source}</span>
                        <span className="text-xs text-gray-400">{article.date}</span>
                      </div>
                      <h3 className="font-bold text-black mb-2">{article.title}</h3>
                      <p className="text-sm text-gray-500 mb-6 line-clamp-2">{article.summary}</p>
                      <div className="flex gap-2">
                        <button onClick={() => approveNews(article.id)} className="flex-1 bg-black text-white py-2 rounded font-bold text-xs flex items-center justify-center gap-2">
                          <CheckCircle size={14} /> Approve & Publish
                        </button>
                        <button onClick={() => deleteNews(article.id)} className="px-4 py-2 border border-gray-200 rounded text-red-600 hover:bg-red-50 transition">
                          <Trash2 size={16} />
                        </button>
                      </div>
                   </div>
                 ))}
               </div>
               {newsArticles.filter(a => a.status === 'pending').length === 0 && (
                 <div className="text-center py-20 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                    <p className="text-gray-400 font-medium">No pending articles in queue. Click 'Fetch' to scan for updates.</p>
                 </div>
               )}
            </div>
          )}

          {/* TAB: BUILDERS */}
          {activeTab === 'Builders' && (
            <div className="space-y-8">
               <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                 <h2 className="text-xl font-bold mb-6">Register New Partner Builder</h2>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                   <input type="text" placeholder="Builder Name" className="p-3 border rounded-lg" value={builderForm.name} onChange={e => setBuilderForm({...builderForm, name: e.target.value})} />
                   <input type="text" placeholder="Tarion/HCRA License #" className="p-3 border rounded-lg" value={builderForm.licenseNumber} onChange={e => setBuilderForm({...builderForm, licenseNumber: e.target.value})} />
                   <input type="text" placeholder="Office Location" className="p-3 border rounded-lg" value={builderForm.officeLocation} onChange={e => setBuilderForm({...builderForm, officeLocation: e.target.value})} />
                   <button onClick={() => { if(builderForm.name) addBuilder(builderForm as any); setBuilderForm({name:'', licenseNumber:'', officeLocation:'', rating:5}) }} className="bg-black text-white py-3 rounded-lg font-bold">Add Builder Profile</button>
                 </div>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 {builders.map(builder => (
                   <div key={builder.id} className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                      <h3 className="font-bold text-black mb-1">{builder.name}</h3>
                      <p className="text-xs text-gray-500 mb-3">License: {builder.licenseNumber}</p>
                      <div className="flex items-center gap-1 text-yellow-500 mb-4">
                        {[1,2,3,4,5].map(s => <Plus key={s} size={12} fill="currentColor" />)}
                      </div>
                      <button className="text-sm font-bold border-t border-gray-100 pt-4 w-full text-left">View Linked Projects</button>
                   </div>
                 ))}
               </div>
            </div>
          )}

          {/* TAB: BULK IMPORT */}
          {activeTab === 'Bulk' && (
            <div className="max-w-2xl mx-auto space-y-8">
               <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200 text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Download className="text-black" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">Mass Data Upload</h2>
                  <p className="text-gray-500 mb-8">Upload a CSV or Excel file to populate multiple property listings or builder profiles at once.</p>
                  
                  <div className="border-2 border-dashed border-gray-200 rounded-xl p-10 mb-8">
                    <p className="text-sm text-gray-400 mb-4">Drag and drop your file here or click to browse</p>
                    <input type="file" className="hidden" id="bulk-file" />
                    <label htmlFor="bulk-file" className="bg-black text-white px-6 py-3 rounded-lg font-bold cursor-pointer hover:bg-gray-800 transition">Select File</label>
                  </div>

                  <div className="flex gap-4 justify-center">
                    <a href="#" className="text-xs font-bold underline text-gray-400">Download Properties Template</a>
                    <a href="#" className="text-xs font-bold underline text-gray-400">Download Builder Template</a>
                  </div>
               </div>
            </div>
          )}

          {/* TAB: SETTINGS */}
          {activeTab === 'Settings' && (
            <div className="max-w-3xl space-y-8">
               <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
                  <h2 className="text-xl font-bold mb-8">Global Feature Toggles</h2>
                  <div className="space-y-6">
                    {[
                      { id: 'enableMortgageCalculator', label: 'Mortgage Calculator', desc: 'Display the main repayment calculator across the site.' },
                      { id: 'enableTriggerRateTool', label: 'Trigger Rate Tool', desc: 'Allow users to calculate variable rate break points.' },
                      { id: 'enableLTTCalculator', label: 'Land Transfer Tax', desc: 'Enable closing cost estimation tools.' },
                      { id: 'enableNewsScraper', label: 'Automated News Scraper', desc: 'Background fetching of real estate news articles.' },
                      { id: 'useExternalRatesWidget', label: 'External Rates Widget', desc: 'Swap the internal ticker with a GoPineapple official widget.' }
                    ].map(item => (
                      <div key={item.id} className="flex items-center justify-between py-4 border-b border-gray-50 last:border-0">
                         <div>
                           <h4 className="font-bold text-black">{item.label}</h4>
                           <p className="text-sm text-gray-500">{item.desc}</p>
                         </div>
                         <button 
                            onClick={() => updateSettings({ [item.id]: !siteSettings[item.id as keyof typeof siteSettings] })}
                            className={`w-12 h-6 rounded-full transition-colors relative ${siteSettings[item.id as keyof typeof siteSettings] ? 'bg-black' : 'bg-gray-200'}`}
                          >
                           <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${siteSettings[item.id as keyof typeof siteSettings] ? 'left-7' : 'left-1'}`} />
                         </button>
                      </div>
                    ))}

                    {/* Rates Widget URL Configuration */}
                    {siteSettings.useExternalRatesWidget && (
                      <div className="pt-6 border-t border-gray-100 animate-fade-in">
                         <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Pineapple Widget Source URL</label>
                         <div className="flex gap-2">
                            <div className="flex-1 bg-gray-50 p-4 rounded-xl flex items-center gap-3">
                               <LinkIcon size={16} className="text-gray-400" />
                               <input 
                                 type="text" 
                                 value={siteSettings.ratesWidgetUrl} 
                                 onChange={(e) => updateSettings({ ratesWidgetUrl: e.target.value })}
                                 className="bg-transparent border-none outline-none w-full font-bold text-sm"
                                 placeholder="https://gopineapple.ca/..."
                               />
                            </div>
                            <button className="bg-black text-white px-6 rounded-xl font-bold text-xs uppercase">Save</button>
                         </div>
                         <p className="mt-2 text-[10px] text-gray-400 italic">Ensure the URL includes 'embed=true' if supported by the brokerage portal.</p>
                      </div>
                    )}
                  </div>
               </div>
            </div>
          )}

          {/* TAB: RATES */}
          {activeTab === 'Rates' && (
            <div className="space-y-6">
               {siteSettings.useExternalRatesWidget && (
                 <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-r-xl mb-6">
                    <p className="text-sm text-yellow-800 font-bold">External Widget Active</p>
                    <p className="text-xs text-yellow-700">The manual rates below are currently hidden on the homepage in favor of the GoPineapple widget. Switch off the widget in 'Settings' to return to manual mode.</p>
                 </div>
               )}
               <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
                  <h3 className="font-bold text-lg mb-4">{editingId ? 'Edit Rate' : 'Add New Rate'}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                    <input type="text" className="p-3 border rounded-lg" placeholder="e.g. 5-Year Fixed" value={rateForm.term} onChange={e => setRateForm({...rateForm, term: e.target.value})} />
                    <input type="number" step="0.01" className="p-3 border rounded-lg" placeholder="e.g. 4.99" value={rateForm.rate} onChange={e => setRateForm({...rateForm, rate: parseFloat(e.target.value)})} />
                    <select className="p-3 border rounded-lg bg-white" value={rateForm.type} onChange={e => setRateForm({...rateForm, type: e.target.value as any})}><option value="Fixed">Fixed</option><option value="Variable">Variable</option></select>
                    <button onClick={handleSaveRate} className="bg-black text-white py-3 rounded-lg font-bold">{editingId ? 'Update' : 'Add Rate'}</button>
                  </div>
               </div>
               <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 text-gray-500 text-xs font-bold uppercase border-b border-gray-200"><tr className="px-6 py-4"><th>Term</th><th>Rate (%)</th><th>Type</th><th>Action</th></tr></thead>
                    <tbody className="divide-y divide-gray-100">{rates.map(rate => (<tr key={rate.id} className="hover:bg-gray-50"><td>{rate.term}</td><td>{rate.rate.toFixed(2)}%</td><td>{rate.type}</td><td className="flex gap-2"><button onClick={() => handleEditClick(rate)}><Edit2 size={16}/></button><button onClick={() => deleteRate(rate.id)} className="text-red-500"><Trash2 size={16}/></button></td></tr>))}</tbody>
                  </table>
               </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default Admin;
