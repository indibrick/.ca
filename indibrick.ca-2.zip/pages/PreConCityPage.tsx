import React, { useEffect, useState } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { PRE_CON_CITIES } from '../data/cityData';
import { ArrowRight, Lock, CheckCircle, FileText, Building, MapPin, Zap, TrendingUp, Home, Building2, UserCheck } from 'lucide-react';
import LeadForm from '../components/LeadForm';

const PreConCityPage: React.FC = () => {
  const { city } = useParams<{ city: string }>();
  const citySlug = city?.replace('pre-construction-condos-', '') || '';
  const cityData = PRE_CON_CITIES.find(c => c.slug === citySlug);
  
  // If city is in footer ecosystem but not in MOCK PRE_CON_CITIES, we use a fallback name
  const cityName = cityData ? cityData.cityName : citySlug.charAt(0).toUpperCase() + citySlug.slice(1);

  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    document.title = `Pre-Construction Projects in ${cityName} | Platinum Access | IndiBrick`;
    window.scrollTo(0, 0);
  }, [cityName]);

  const categories = [
    {
      id: 'condos',
      name: 'Luxury Condos',
      icon: <Building2 size={40} />,
      desc: `High-rise living with premium amenities in the core of ${cityName}.`,
      type: 'Pre-Con'
    },
    {
      id: 'townhomes',
      name: 'Modern Townhomes',
      icon: <Home size={40} />,
      desc: `Spacious multi-level residences designed for families in ${cityName}.`,
      type: 'Pre-Con'
    },
    {
      id: 'freehold',
      name: 'Freehold Townhomes',
      icon: <Building size={40} />,
      desc: `No maintenance fees. Full ownership in established ${cityName} communities.`,
      type: 'Pre-Con'
    }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="bg-black text-white py-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black"></div>
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.3em] mb-8">
              <Zap size={14} className="text-white" /> Platinum Investor Network
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-8 leading-tight tracking-tighter uppercase">
              {cityName} Pre-Construction
            </h1>
            <p className="text-xl text-gray-400 mb-10 leading-relaxed max-w-2xl font-medium">
              We connect you directly with the top projects in {cityName}. Secure your unit before it hits the general public with VIP pricing and floor plans.
            </p>
            <div className="flex flex-wrap gap-6">
               <span className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white/60">
                 <CheckCircle size={14} className="text-white" /> Platinum Broker Status
               </span>
               <span className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white/60">
                 <CheckCircle size={14} className="text-white" /> Pre-Approval Qualification
               </span>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-24 container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-black text-black mb-4 uppercase tracking-tighter">Available Project Types</h2>
          <p className="text-gray-500 font-medium">Select a category to connect with our specialists and view restricted data.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {categories.map((cat) => (
            <div key={cat.id} className="group bg-gray-50 border border-gray-100 p-10 rounded-[2rem] hover:bg-black hover:border-black transition-all duration-500 flex flex-col items-center text-center shadow-sm hover:shadow-2xl">
              <div className="mb-8 text-black group-hover:text-white transition-colors duration-500">
                {cat.icon}
              </div>
              <h3 className="text-2xl font-black text-black group-hover:text-white mb-4 uppercase tracking-tight transition-colors duration-500">
                {cat.name}
              </h3>
              <p className="text-gray-500 group-hover:text-gray-400 mb-10 transition-colors duration-500 leading-relaxed font-medium">
                {cat.desc}
              </p>
              <button 
                onClick={() => {
                  setSelectedCategory(cat.name);
                  document.getElementById('connect-form')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="mt-auto w-full bg-black text-white group-hover:bg-white group-hover:text-black py-4 rounded-2xl font-black uppercase text-xs tracking-widest transition-all duration-500 flex items-center justify-center gap-2"
              >
                Connect Now <ArrowRight size={16} />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Information & Disclaimer Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto bg-white p-12 rounded-[2.5rem] shadow-xl border border-gray-100">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-black text-white rounded-xl flex items-center justify-center">
                <UserCheck size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-black text-black uppercase tracking-tight">The Qualification Process</h3>
                <p className="text-sm text-gray-400 font-bold uppercase tracking-widest">Financing First Methodology</p>
              </div>
            </div>
            
            <div className="space-y-6 text-gray-600 leading-relaxed mb-12 font-medium">
              <p>
                In the competitive {cityName} pre-construction market, builders require a verified mortgage pre-approval or commitment letter before confirming your unit allocation. 
                Our ecosystem ensures you are qualified <strong>before</strong> you sign.
              </p>
              <p>
                Once you submit the request below, our licensed mortgage team will reach out to assess your borrowing power. 
                Simultaneously, our partner realtors will provide the latest floor plans, price lists, and allocation details.
              </p>
            </div>

            <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100 text-center">
               <p className="text-[11px] text-gray-500 font-black uppercase tracking-widest leading-relaxed">
                 <Lock size={12} className="inline mr-2" /> 
                 Disclaimer: The information provided in the form below will be shared with our licensed mortgage agent to connect with you for qualification purposes, as well as our designated partner realtors to assist with project details and sales.
               </p>
            </div>
          </div>
        </div>
      </section>

      {/* Lead Form Section */}
      <section id="connect-form" className="py-32">
        <div className="container mx-auto px-6">
           <div className="max-w-4xl mx-auto">
              <div className="text-center mb-16">
                 <h2 className="text-4xl md:text-6xl font-black text-black mb-4 uppercase tracking-tighter">
                   Request {selectedCategory || 'Project'} Access
                 </h2>
                 <p className="text-xl text-gray-500 font-medium">Complete the form to unlock floor plans, pricing, and financing strategy in {cityName}.</p>
              </div>
              <LeadForm 
                type="Pre-Con" 
                title={`Secure Your ${cityName} Unit`} 
                subtitle={`Connecting you with Mudit Chhura (Mortgage) & Local ${cityName} Real Estate Partners.`}
              />
           </div>
        </div>
      </section>

      {/* Local Authority & Market Info */}
      <section className="py-24 bg-gray-50 border-t border-gray-100">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
            <div>
              <h2 className="text-3xl font-black text-black mb-6 uppercase tracking-tight leading-none">Why invest in {cityName} now?</h2>
              <div className="space-y-8">
                <div className="flex gap-4">
                  <TrendingUp className="text-black shrink-0" size={24} />
                  <div>
                    <h4 className="font-black text-black uppercase text-sm mb-1">Projected Growth</h4>
                    <p className="text-sm text-gray-500">Ongoing infrastructure investments in {cityName} are driving double-digit demand growth for new residential units.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <FileText className="text-black shrink-0" size={24} />
                  <div>
                    <h4 className="font-black text-black uppercase text-sm mb-1">Rental Yields</h4>
                    <p className="text-sm text-gray-500">{cityName} remains one of the highest cash-flow regions for new builds in Ontario, supported by strong employment data.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-black text-white p-12 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16"></div>
               <h3 className="text-2xl font-black mb-6 uppercase tracking-tight">Need a Pre-Approval First?</h3>
               <p className="text-gray-400 mb-10 font-medium leading-relaxed">
                 Builders in {cityName} will not accept offers without a firm financing letter. Get yours today through Pineapple's automated portal.
               </p>
               <a 
                 href="https://gopineapple.ca/muditchhura/preapproval" 
                 target="_blank" 
                 className="inline-flex items-center gap-3 bg-white text-black px-10 py-5 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-gray-200 transition-all shadow-xl"
               >
                 Get Pre-Approved <Zap size={16} />
               </a>
            </div>
          </div>
        </div>
      </section>

      {/* Global Internal Links */}
      <section className="py-20 border-t border-gray-100">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-xs font-black text-gray-300 mb-8 uppercase tracking-[0.4em]">Explore the Ecosystem</h2>
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-6">
            <Link to={`/mortgage-real-estate-${citySlug}`} className="text-gray-500 font-black uppercase text-[10px] tracking-[0.2em] hover:text-black transition">
              {cityName} Mortgage Hub
            </Link>
            <Link to="/listings" className="text-gray-500 font-black uppercase text-[10px] tracking-[0.2em] hover:text-black transition">
              GTA Resale Directory
            </Link>
            <Link to="/tools" className="text-gray-500 font-black uppercase text-[10px] tracking-[0.2em] hover:text-black transition">
              Closing Cost Calculator
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PreConCityPage;
